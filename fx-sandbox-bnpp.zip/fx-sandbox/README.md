# FX sandbox

A lightweight foreign-exchange sandbox for trying out limit orders without touching real markets.
It starts with **USD 10,000**, simulates **USD/EUR, USD/GBP and USD/CHF** with a random walk seeded
from live ECB rates, fills limit orders when the simulated rate reaches them, and shows the order book,
positions and P&L live.

- **Back end:** C# / ASP.NET Core 8 Web API, SignalR, xUnit
- **Front end:** React 18, TypeScript, Vite, `@microsoft/signalr`

![The sandbox in the dark theme: three live pair charts with resting orders drawn at their limits, the order ticket, and fill notifications](docs/screenshot.png)

---

## Contents

1. [Running it](#running-it)
2. [A quick tour](#a-quick-tour)
3. [Architecture](#architecture)
4. [API](#api)
5. [Domain decisions](#domain-decisions)
6. [Assumptions](#assumptions)
7. [Why ASP.NET Core rather than Nancy](#why-aspnet-core-rather-than-nancy)
8. [Testing](#testing)
9. [What I'd add for production](#what-id-add-for-production)

---

## Running it

**Prerequisites:** [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8.0) and Node.js 20.19 or later.

### Option 1: development (hot reload)

Run the API and the Vite dev server in two terminals:

```bash
# Terminal 1: API on http://localhost:5080
cd backend/src/FxSandbox.Api
dotnet run

# Terminal 2: UI on http://localhost:5173 (proxies /api and /hubs to :5080)
cd frontend
npm install
npm run dev
```

Open **http://localhost:5173**.

### Option 2: one process

Build the front end into the API's `wwwroot`, then run the API on its own:

```bash
cd frontend && npm install && npm run build
cd ../backend/src/FxSandbox.Api && dotnet run
```

Open **http://localhost:5080**. The API serves the app with a SPA fallback.

### Useful URLs

| URL | What |
| --- | --- |
| http://localhost:5080/swagger | Swagger UI, with XML doc comments |
| http://localhost:5080/health | Health check (JSON): is the simulation ticking? |
| ws://localhost:5080/hubs/sandbox | SignalR hub |

### Tests

```bash
cd backend && dotnet test          # 73 xUnit tests: domain unit tests and HTTP/SignalR integration tests
cd frontend && npm test            # Vitest: ticket, rounding and history logic
cd frontend && npm run lint
```

The API tries live rates at start-up and falls back to configured rates if they aren't available within 4 seconds,
so it runs offline too. To skip the network call, set `LiveRates__Enabled=false`.

---

## A quick tour

- **Live charts, one per pair.** Each chart shows the last 180 ticks, a spot tag, and every resting order as a dashed
  line at its limit: amber for sells, blue for buys, each labelled. Orders more than 0.5% from spot are pinned to the top or
  bottom edge with an arrow and their distance. Hover for a crosshair showing the rate under the cursor; **click to set the
  order ticket's limit to that rate.**
- **Order ticket.** Choose a pair and a side (*Sell USD / receive EUR* or *Buy USD / pay with EUR*), then an amount in USD
  and a limit rate with ±1 pip buttons. The limit follows the market until you edit it. A live summary shows what you pay,
  what you receive and what's available, with a plain-English fill condition: *"Fills when USD/EUR rises to 0.88000 or
  higher"*, or *"…already marketable and fills now"*. Orders you can't afford are blocked before submission, with the same
  message the server would return.
- **Order book.** *Open* orders show a distance-to-fill bar and a Cancel button. *Filled and cancelled* shows fill
  rates and amounts.
- **Positions.** Holding, average rate, current rate, cost, value, and unrealised and realised P&L, with signs on every figure.
- **Cash.** Each currency's balance, the amount reserved by open orders, and what's available.
- **Header.** Account value and its change, unrealised and realised P&L, starting capital, a Live / Reconnecting
  indicator, a theme toggle and a two-step Reset. The seed source is shown under the title.
- **Toast on every fill,** including fills on later ticks.
- Dark navy theme by default, and a light theme on warm paper tones. IBM Plex Sans, with IBM Plex Mono and tabular figures for numbers.
  Responsive down to phone width, with visible focus states. Motion is disabled under `prefers-reduced-motion`.

---

## Architecture

```
┌──────────────── Browser (React) ────────────────┐
│  useSandbox ◄── SignalR "snapshot" pushes        │
│  api.ts ──► REST: place / cancel / reset         │
└──────────────────────┬──────────────────────────┘
          REST /api/*  │  WebSocket /hubs/sandbox
┌──────────────────────▼──────── FxSandbox.Api ───┐
│ Controllers ──┐        SandboxHub (push only)    │
│ ExceptionFilter → ProblemDetails                 │
│ RateSeedingService (start-up: Frankfurter/ECB)   │
│ TickerService (PeriodicTimer) ─► SnapshotBroadcaster
└──────────────┬───────────────────────────────────┘
               │  one lock
┌──────────────▼──────────────── FxSandbox.Core ──┐
│ SandboxEngine: rates, order book, matching,      │
│ Wallet (cash + reservations), Positions, P&L     │
│ RandomWalk · IRandomSource · TimeProvider        │
└──────────────────────────────────────────────────┘
```

### Projects

| Project | Responsibility |
| --- | --- |
| `backend/src/FxSandbox.Core` | The domain, with **no ASP.NET dependencies.** `SandboxEngine` owns the simulated rates, the order book, matching and the wallet. It exposes immutable snapshot records as its read model. Domain entities (`Order`, `Position`, `Wallet`) are `internal`, so nothing outside the engine can mutate state. |
| `backend/src/FxSandbox.Api` | The host: controllers, the SignalR hub, hosted services (seeding and ticker), the health check, Swagger, ProblemDetails mapping and static hosting of the SPA. |
| `backend/tests/FxSandbox.Tests` | xUnit tests: domain unit tests against the engine, plus integration tests through `WebApplicationFactory`. |
| `frontend` | React + TypeScript + Vite. Pure logic (`lib/`, `api/history.ts`) is kept apart from components and unit-tested. |

### Key design choices

- **One engine, one lock.** `SandboxEngine` is a singleton, and every public member takes the same lock, so a tick and a
  trader action never interleave. Every snapshot is internally consistent: balances, orders and P&L always agree. At one tick
  per second with a single account, contention is negligible, and the model is much easier to reason about than fine-grained locking.
- **REST for commands, SignalR for state.** Trader actions go through REST only, so validation and error handling live in one
  place, with proper status codes and ProblemDetails. The hub only pushes: it sends a full snapshot with rate history on connect,
  then a snapshot every tick and immediately after every place, cancel or reset. The client never needs to merge partial deltas,
  and reconnecting is simply "get a new full snapshot". Snapshots stay small because closed orders and fills are capped.
- **Seeding before ticking.** Hosted services start in registration order, so `RateSeedingService` has seeded the walk before
  `TickerService` starts and before the server accepts requests.
- **Deterministic by injection.** `IRandomSource` and `TimeProvider` are injected. Tests script the walk (0.5 means no move,
  1 means +0.1%, 0 means −0.1%) and use `FakeTimeProvider`, so matching and P&L tests are exact rather than statistical.
- **Expected rejections aren't errors.** Domain exceptions (`OrderValidationException`, `InsufficientFundsException`,
  `OrderNotFoundException`, `OrderNotCancellableException`) are mapped to ProblemDetails by an MVC exception filter, so they don't
  show up as unhandled-exception error logs. Genuine faults still go through `UseExceptionHandler` and become a 500 ProblemDetails.
- **Configuration validated at start-up** (`ValidateDataAnnotations().ValidateOnStart()`), so a bad setting fails fast.
- **No warnings.** `TreatWarningsAsErrors`, `AnalysisLevel=latest-recommended` and XML docs on every public member.

### Configuration (`appsettings.json`)

| Setting | Default | Meaning |
| --- | --- | --- |
| `Sandbox:StartingCapital` | 10000 | USD cash at start and after reset |
| `Sandbox:HistoryLength` | 180 | Rates kept per pair |
| `Sandbox:MaxStep` | 0.001 | Δ bound per tick (±0.1%) |
| `Sandbox:MaxLimitDeviation` | 0.2 | Fat-finger check: the limit must be within 20% of spot |
| `Sandbox:FallbackRates` | EUR 0.8789, GBP 0.7462, CHF 0.8012 | Used when live rates are off or unavailable |
| `Ticker:IntervalMs` | 1000 | Tick interval |
| `LiveRates:Enabled` / `Url` / `TimeoutSeconds` | true / Frankfurter / 4 | Live seed source |

---

## API

All responses are JSON with camelCase properties and **enums as strings**. Errors are RFC 7807 ProblemDetails
(`application/problem+json`). The full contract, with examples, is in Swagger.

| Method | Path | Description |
| --- | --- | --- |
| `GET` | `/api/snapshot?history=bool` | Everything at one instant: rates, orders, fills, positions, balances, account |
| `GET` | `/api/rates?history=bool` | Latest rate per pair |
| `GET` | `/api/orders?status=Open` | Orders: open ones oldest first, then closed ones newest first. `status` is optional: `Open`, `Filled` or `Cancelled` |
| `GET` | `/api/orders/{id}` | One order |
| `POST` | `/api/orders` | Place a limit order → **201** with `{ order, fill }`. `fill` is set if the order was already marketable |
| `DELETE` | `/api/orders/{id}` | Cancel → **204**, **404** if unknown, **409** if already filled or cancelled |
| `GET` | `/api/positions` | One position per pair, marked to market |
| `GET` | `/api/account` | Account totals and per-currency balances |
| `POST` | `/api/reset` | Back to starting capital with no orders or positions. Returns the new snapshot |
| `GET` | `/health` | `Healthy` while ticks are arriving; `Unhealthy` after 5 missed intervals |

```http
POST /api/orders
Content-Type: application/json

{ "pair": "USD/EUR", "side": "Sell", "quantity": 1000, "limitPrice": 0.88 }
```

Rejections look like this:

```json
{
  "type": "https://tools.ietf.org/html/rfc4918#section-11.2",
  "title": "Insufficient funds",
  "status": 422,
  "detail": "Not enough EUR: this order needs 449.00 and 0.00 is available.",
  "currency": "EUR", "required": 449.00, "available": 0
}
```

| Status | When |
| --- | --- |
| 400 | Missing or invalid fields: unknown pair, quantity ≤ 0 or more than 2 dp, limit ≤ 0 or more than 5 dp, or limit more than 20% from spot. Returned as `ValidationProblemDetails` with per-field `errors` |
| 422 | Not enough available funds to reserve for the order |
| 404 / 409 | Unknown order / order no longer open |

**Hub:** `GET /hubs/sandbox`. The client method is `snapshot(SandboxSnapshot)`. Clients don't call any hub methods.

---

## Domain decisions

**Quoting.** Pairs are BASE/QUOTE with USD as the base. The rate is **quote units per 1 USD**, so USD/EUR 0.8789 means
1 USD = 0.8789 EUR.

**Side refers to USD,** following market convention:

| Side | Meaning | Fills when | Reserves |
| --- | --- | --- | --- |
| **Sell** | Sell USD, receive the quote currency | rate **≥** limit | the USD quantity |
| **Buy** | Buy USD back, paying in the quote currency | rate **≤** limit | quantity × limit in the quote currency |

**Multi-currency wallet, no leverage or shorting.** The wallet holds USD, EUR, GBP and CHF. Placing an order reserves
the funds it needs; if the *available* balance (balance − reserved) is short, the order is rejected with a clear message,
such as *"Not enough EUR: this order needs 449.00 and 0.00 is available."* Cancelling releases the reservation. So you
can only buy USD back with currency you got by selling USD first.

**Fills.** An order fills at the **current spot rate on the tick that triggers it**, which is always at the limit or better.
An order that is already marketable when placed fills immediately at spot. When several orders trigger on the same tick they
fill in price-time priority: most aggressive limit first, then **oldest first at the same level**. Every order fills in
full; there are no partial fills.

**Positions.** A position is the quote-currency amount held per pair, with its **cost basis in USD**:

- Selling USD adds the quote amount received and adds the USD sold to the cost basis.
- Buying USD back pays quote currency, reduces the cost basis **pro rata** (`cost × paid ÷ held`), and books
  **realised P&L = USD received − cost released.**
- **Unrealised P&L = amount ÷ current rate − cost basis.**
- Average rate = amount ÷ cost basis.

**Account.** Account value = USD cash + every position marked to USD. The header shows starting capital, account value,
unrealised P&L and realised P&L. By construction, **account value = starting capital + unrealised + realised.** A
randomised test checks this over thousands of ticks and orders.

**Precision.** `decimal` everywhere on the server. Rates are 5 dp and amounts are 2 dp, with both validated on input. Amounts round half
away from zero. The random walk rounds each step *towards the previous rate*, so rounding can never push a step past ±0.1%.
The UI rounds the same way, trimming binary floating-point noise first, so its "can I afford this?" check agrees with the server.

**Rate simulation.** `newRate = oldRate × (1 + Δ)`, with Δ uniform in [−0.001, +0.001], once per tick (1000 ms by default)
from a `BackgroundService` driven by a `PeriodicTimer`. The walk is seeded with live ECB reference rates from
`https://api.frankfurter.dev/v1/latest?base=USD&symbols=EUR,GBP,CHF` (4 s timeout), falling back to configured rates. The
UI shows which source was used. The last 180 rates per pair are kept for the charts.

---

## Assumptions

- **A single shared account.** The brief describes one sandbox with USD 10,000 and no users, so there is one account in
  memory. Every browser sees the same state, which also makes the real-time push easy to demo in two windows.
- **In-memory state.** Restarting the API starts a fresh sandbox. Reset clears the account but leaves the market running,
  because the market isn't the trader's to reset.
- **Limit orders only, filled in full.** No market orders, partial fills or expiry, since the brief asks for limit orders.
- **A fat-finger check** rejects limits more than 20% from spot. That's not in the brief, but it's cheap, it catches typos like
  8.8 for 0.88, and it's configurable.
- **Each pair walks independently.** There's no correlation or cross-rate consistency between EUR, GBP and CHF.
- **Retention.** The last 200 closed orders and 100 fills are kept, so snapshots stay small.
- **No authentication.** It's a local sandbox; see below for production.

---

## Why ASP.NET Core rather than Nancy

The brief mentions Nancy or ASP.NET. **Nancy is archived:** its maintainers stopped development in 2020 and the GitHub
repository is now read-only, so it gets no updates or security fixes and doesn't follow current .NET releases. That's not
something a bank would put into production, and a take-home should reflect what I'd actually ship. ASP.NET Core 8 is the supported LTS
framework and provides what this project needs out of the box: controllers, SignalR for real-time push, hosted services
for the simulation, `ProblemDetails`, health checks, options validation, `TimeProvider`, and first-class integration
testing with `WebApplicationFactory`. The domain lives in a plain class library, so the choice of web framework
only touches the thin API layer.

---

## Testing

**Back end (xUnit, 73 tests)**

| Area | What's covered |
| --- | --- |
| Random walk | Δ maps [0, 1] onto [−0.001, +0.001] and rejects out-of-range samples; 10,000 steps (several seeds, plus both extremes) each stay within ±0.1% and at 5 dp |
| Reservations | Sell reserves USD; buy reserves quantity × limit in quote currency; reserved funds are unavailable to later orders; exactly-available is accepted |
| Matching | Sell fills on a rise, buy on a fall, and neither fills in the wrong direction; fills at spot (at the limit or better); marketable orders fill immediately; FIFO at the same level; price-time priority; orders react only to their own pair |
| P&L | Position and cost basis on sell; unrealised P&L moves with the rate (both directions); realised P&L and pro-rata cost reduction on buy-back, including losses and a full close |
| Invariant | **equity = starting capital + unrealised + realised**, and no negative balances, checked after every step of 2,000-step randomised sessions |
| Rejections | Insufficient funds (exact message), invalid pair, quantity and price, all errors reported together |
| Cancel and reset | Cancel releases funds and can't be repeated; filled orders can't be cancelled; unknown ids aren't found; reset restores capital but keeps the market; history and retention limits |
| HTTP integration | Order lifecycle over HTTP (201 + Location → listed → reserved → 204 → 409); immediate fill; 422 and 400 ProblemDetails; model-binding errors; 404s; reset; health; Swagger with string enums |
| SignalR | A new connection receives a snapshot with history, then a push after a REST action |

Integration tests turn live rates off and use a flat random source, so the market stands still and every result is deterministic.

**Front end (Vitest):** fill conditions and wording, distance to fill, ticket flows and max quantity, input validation,
rounding parity with the server, the ticket reducer (follows the market until edited, nudges by a pip), and rate-history merging.

**CI (GitHub Actions):** `dotnet build` (warnings as errors) and `dotnet test`, then `npm ci`, lint, test and build.

---

## What I'd add for production

- **Authentication and authorisation.** Azure AD (Entra ID) with JWT bearer tokens on the API and the hub, and MSAL in the SPA.
  Role-based policies, for example read-only versus trader.
- **Persistence with EF Core.** Orders, fills and positions in SQL Server or Postgres. Every fill would be an append-only
  ledger entry, with balances derived from the ledger or reconciled against it. Optimistic concurrency, and an outbox for fill events.
- **Per-user accounts.** An engine or wallet per account, keyed by user id, with SignalR groups per user so each trader only
  receives their own state. The single lock becomes a lock per account; the rate feed stays shared.
- **Partial fills and order types.** Partial fills against simulated liquidity, market orders, time-in-force (GTC, IOC, day),
  order amendments, and stop orders.
- **Docker.** A multi-stage Dockerfile (Node build, then .NET publish, then a slim ASP.NET runtime image running as non-root),
  a compose file for local dependencies, health checks wired to the orchestrator, and deployment to Azure Container Apps or AKS.
- **Scale-out.** A SignalR backplane (Azure SignalR Service or Redis) and a single leader for the ticker.
- **Observability.** OpenTelemetry traces and metrics (ticks, fills, rejections, hub connections), structured logs
  with correlation ids, and alerts on the health check.
- **Hardening.** HTTPS and HSTS, rate limiting on order placement, CORS and CSP policies, idempotency keys on `POST /api/orders`,
  and API versioning.
- **More testing.** Playwright end-to-end tests of the UI, contract tests generated from the OpenAPI document, and mutation testing on the engine.

---

## Project layout

```
backend/
  FxSandbox.sln
  Directory.Build.props        # net8.0, nullable, warnings as errors, analyzers
  src/FxSandbox.Core/          # domain: engine, wallet, positions, random walk, snapshots
  src/FxSandbox.Api/           # controllers, hub, hosted services, health, Swagger, SPA host
  tests/FxSandbox.Tests/       # Domain/ unit tests, Api/ integration tests
frontend/
  src/api/                     # REST client, SignalR hook, snapshot types, history merge
  src/lib/                     # pure order, ticket and formatting logic (unit-tested)
  src/components/              # PairChart, OrderTicket, OrderBook, Positions, CashPanel, Header, Toasts
.github/workflows/ci.yml
```
