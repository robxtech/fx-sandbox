import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';

const api = 'http://localhost:5080';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': api,
      '/health': api,
      '/swagger': api,
      '/hubs': { target: api, ws: true },
    },
  },
  build: {
    // The API serves the built app from wwwroot, so one `dotnet run` serves everything.
    outDir: '../backend/src/FxSandbox.Api/wwwroot',
    emptyOutDir: true,
  },
  test: {
    environment: 'node',
  },
});
