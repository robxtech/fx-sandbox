import type { Side } from '../api/types';
import { PIP, roundRate } from './orders';

/** The order ticket's state. While `following` is true, the limit tracks the live rate. */
export interface TicketState {
  pair: string;
  side: Side;
  amount: string;
  limit: string;
  following: boolean;
}

export type TicketAction =
  | { type: 'pair'; pair: string }
  | { type: 'side'; side: Side }
  | { type: 'amount'; amount: string }
  | { type: 'limit'; limit: string }
  | { type: 'nudge'; pips: number; spot: number }
  | { type: 'follow' }
  | { type: 'pick'; pair: string; price: number };

export const initialTicket: TicketState = {
  pair: 'USD/EUR',
  side: 'Sell',
  amount: '1000',
  limit: '',
  following: true,
};

/** The limit as shown: the live rate while following, otherwise what the trader typed. */
export const effectiveLimit = (state: TicketState, spot: number | undefined): string =>
  state.following && spot !== undefined ? spot.toFixed(5) : state.limit;

export function ticketReducer(state: TicketState, action: TicketAction): TicketState {
  switch (action.type) {
    case 'pair':
      return action.pair === state.pair ? state : { ...state, pair: action.pair, following: true };
    case 'side':
      return { ...state, side: action.side };
    case 'amount':
      return { ...state, amount: action.amount };
    case 'limit':
      return { ...state, limit: action.limit, following: false };
    case 'nudge': {
      const base = Number(effectiveLimit(state, action.spot));
      const from = Number.isFinite(base) && base > 0 ? base : action.spot;
      return { ...state, limit: roundRate(from + action.pips * PIP).toFixed(5), following: false };
    }
    case 'follow':
      return { ...state, following: true };
    case 'pick':
      return { ...state, pair: action.pair, limit: action.price.toFixed(5), following: false };
  }
}
