import { describe, expect, it } from 'vitest';
import { effectiveLimit, initialTicket, ticketReducer } from './ticket';

describe('ticket', () => {
  it('follows the market until the limit is edited', () => {
    expect(effectiveLimit(initialTicket, 0.87891)).toBe('0.87891');
    const edited = ticketReducer(initialTicket, { type: 'limit', limit: '0.88' });
    expect(effectiveLimit(edited, 0.87891)).toBe('0.88');
    expect(effectiveLimit(ticketReducer(edited, { type: 'follow' }), 0.87891)).toBe('0.87891');
  });

  it('nudges by one pip from the current limit', () => {
    const up = ticketReducer(initialTicket, { type: 'nudge', pips: 1, spot: 0.87891 });
    expect(up.limit).toBe('0.87901');
    expect(up.following).toBe(false);
    expect(ticketReducer(up, { type: 'nudge', pips: -2, spot: 0.9 }).limit).toBe('0.87881');
  });

  it('takes the pair and rate picked on a chart', () => {
    const picked = ticketReducer(initialTicket, { type: 'pick', pair: 'USD/GBP', price: 0.75123 });
    expect(picked).toMatchObject({ pair: 'USD/GBP', limit: '0.75123', following: false });
  });

  it('follows the market again when the pair changes', () => {
    const edited = ticketReducer(initialTicket, { type: 'limit', limit: '0.88' });
    expect(ticketReducer(edited, { type: 'pair', pair: 'USD/CHF' }).following).toBe(true);
  });
});
