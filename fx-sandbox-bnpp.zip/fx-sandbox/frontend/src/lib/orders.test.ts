import { describe, expect, it } from 'vitest';
import {
  describeFill,
  distanceToFill,
  isMarketable,
  maxQuantity,
  proximity,
  roundAmount,
  ticketFlows,
  validateLimit,
  validateQuantity,
} from './orders';

describe('fill conditions', () => {
  it('sells fill on a rise and buys fill on a fall', () => {
    expect(isMarketable('Sell', 0.881, 0.88)).toBe(true);
    expect(isMarketable('Sell', 0.879, 0.88)).toBe(false);
    expect(isMarketable('Buy', 0.879, 0.88)).toBe(true);
    expect(isMarketable('Buy', 0.881, 0.88)).toBe(false);
  });

  it('describes the condition in plain English', () => {
    expect(describeFill('USD/EUR', 'Sell', 0.88, 0.8789)).toBe('Fills when USD/EUR rises to 0.88000 or higher.');
    expect(describeFill('USD/EUR', 'Buy', 0.87, 0.8789)).toBe('Fills when USD/EUR falls to 0.87000 or lower.');
    expect(describeFill('USD/EUR', 'Sell', 0.87, 0.8789)).toMatch(/already marketable and fills now/);
  });

  it('measures distance to fill in the direction the rate must move', () => {
    expect(distanceToFill('Sell', 0.88, 0.8844)).toBeCloseTo(0.005);
    expect(distanceToFill('Buy', 0.88, 0.8756)).toBeCloseTo(0.005);
    expect(proximity(0)).toBe(1);
    expect(proximity(0.0025)).toBeCloseTo(0.5);
    expect(proximity(0.01)).toBe(0);
  });
});

describe('ticket flows', () => {
  it('a sell pays USD and receives the quote currency', () => {
    const flows = ticketFlows('USD/EUR', 'Sell', 500, 0.898);
    expect(flows.pay).toEqual({ amount: 500, currency: 'USD' });
    expect(flows.receive).toEqual({ amount: 449, currency: 'EUR' });
    expect(flows.reserve).toEqual({ amount: 500, currency: 'USD' });
  });

  it('a buy reserves quantity × limit in the quote currency', () => {
    const flows = ticketFlows('USD/GBP', 'Buy', 500, 0.87123);
    expect(flows.pay).toEqual({ amount: 435.62, currency: 'GBP' });
    expect(flows.reserve).toEqual({ amount: 435.62, currency: 'GBP' });
  });

  it('caps the quantity at what the available funds cover', () => {
    expect(maxQuantity('Sell', 1234.567, 0.88)).toBe(1234.56);
    const buy = maxQuantity('Buy', 880, 0.87123);
    expect(Math.round(buy * 0.87123 * 100) / 100).toBeLessThanOrEqual(880);
  });
});

describe('input validation', () => {
  it('checks amounts', () => {
    expect(validateQuantity('1000')).toBeNull();
    expect(validateQuantity('10.25')).toBeNull();
    expect(validateQuantity('10.255')).toMatch(/2 decimal/);
    expect(validateQuantity('0')).toMatch(/greater than zero/);
    expect(validateQuantity('')).toMatch(/Enter/);
  });

  it('checks limit rates', () => {
    expect(validateLimit('0.88123')).toBeNull();
    expect(validateLimit('0.881234')).toMatch(/5 decimal/);
    expect(validateLimit('-1')).toMatch(/greater than zero/);
  });
});

describe('rounding', () => {
  it('matches the server: half away from zero, immune to float noise', () => {
    expect(roundAmount(500 * 0.87123)).toBe(435.62);
    expect(roundAmount(1.005)).toBe(1.01);
    expect(roundAmount(-1.005)).toBe(-1.01);
  });
});
