import type { Side } from '../api/types';

/** One pip for these pairs: the fourth decimal place. */
export const PIP = 0.0001;

/** Orders further than this from spot are pinned to the chart edge. */
export const NEAR_BAND = 0.005;

/**
 * Rounds half away from zero, matching the server's decimal rounding. Binary floating point stores
 * 500 × 0.87123 as 435.61499…, so the scaled value is first trimmed to 12 significant digits.
 */
export const roundTo = (value: number, dp: number): number => {
  const factor = 10 ** dp;
  const scaled = Number((Math.abs(value) * factor).toPrecision(12));
  return (Math.sign(value) * Math.round(scaled)) / factor;
};

export const roundRate = (value: number): number => roundTo(value, 5);
export const roundAmount = (value: number): number => roundTo(value, 2);

/** The quote currency of a pair symbol such as USD/EUR. */
export const quoteOf = (pair: string): string => pair.split('/')[1] ?? pair;

/** A sell fills when the rate rises to the limit or higher; a buy when it falls to the limit or lower. */
export const isMarketable = (side: Side, spot: number, limit: number): boolean =>
  side === 'Sell' ? spot >= limit : spot <= limit;

/**
 * How far the rate still has to move for the order to fill, as a fraction of spot.
 * Zero or less means the order is marketable.
 */
export const distanceToFill = (side: Side, spot: number, limit: number): number =>
  side === 'Sell' ? (limit - spot) / spot : (spot - limit) / spot;

/** 1 when the order is at its limit, falling to 0 at the edge of the near band. */
export const proximity = (distance: number, band = NEAR_BAND): number =>
  Math.min(1, Math.max(0, 1 - distance / band));

/** The plain-English fill condition shown under the order ticket. */
export function describeFill(pair: string, side: Side, limit: number, spot: number): string {
  if (isMarketable(side, spot, limit)) {
    return `${pair} is at ${spot.toFixed(5)}, so this order is already marketable and fills now.`;
  }
  return side === 'Sell'
    ? `Fills when ${pair} rises to ${limit.toFixed(5)} or higher.`
    : `Fills when ${pair} falls to ${limit.toFixed(5)} or lower.`;
}

export interface TicketFlows {
  pay: { amount: number; currency: string };
  receive: { amount: number; currency: string };
  /** The currency and amount the order reserves while open. */
  reserve: { amount: number; currency: string };
}

/** What an order pays and receives if it fills at its limit. It may fill at a better rate. */
export function ticketFlows(pair: string, side: Side, quantity: number, limit: number): TicketFlows {
  const quote = quoteOf(pair);
  const quoteAmount = roundAmount(quantity * limit);
  return side === 'Sell'
    ? {
        pay: { amount: quantity, currency: 'USD' },
        receive: { amount: quoteAmount, currency: quote },
        reserve: { amount: quantity, currency: 'USD' },
      }
    : {
        pay: { amount: quoteAmount, currency: quote },
        receive: { amount: quantity, currency: 'USD' },
        reserve: { amount: quoteAmount, currency: quote },
      };
}

/** The largest USD quantity the available funds can cover at this limit. */
export function maxQuantity(side: Side, available: number, limit: number): number {
  if (side === 'Sell') return Math.floor(available * 100) / 100;
  if (limit <= 0) return 0;
  // Step down until the rounded reservation fits, as the server rounds quantity × limit half away from zero.
  let quantity = Math.floor((available / limit) * 100) / 100;
  while (quantity > 0 && roundAmount(quantity * limit) > available) quantity = roundAmount(quantity - 0.01);
  return quantity;
}

/** Counts decimal places in user input such as "0.88100". */
export const decimalsIn = (text: string): number => {
  const dot = text.indexOf('.');
  return dot < 0 ? 0 : text.length - dot - 1;
};

/** Validates the amount field. Returns an error message, or null when valid. */
export function validateQuantity(text: string): string | null {
  const value = Number(text);
  if (text.trim() === '' || !Number.isFinite(value)) return 'Enter a USD amount.';
  if (value <= 0) return 'Enter a USD amount greater than zero.';
  if (decimalsIn(text.trim()) > 2) return 'Use at most 2 decimal places.';
  return null;
}

/** Validates the limit field. Returns an error message, or null when valid. */
export function validateLimit(text: string): string | null {
  const value = Number(text);
  if (text.trim() === '' || !Number.isFinite(value)) return 'Enter a limit rate.';
  if (value <= 0) return 'Enter a limit rate greater than zero.';
  if (decimalsIn(text.trim()) > 5) return 'Use at most 5 decimal places.';
  return null;
}
