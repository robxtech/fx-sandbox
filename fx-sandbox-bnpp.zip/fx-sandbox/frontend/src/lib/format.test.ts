import { describe, expect, it } from 'vitest';
import { formatPercent, formatSigned, signClass } from './format';

describe('formatting', () => {
  it('signs P&L with a true minus sign', () => {
    expect(formatSigned(12.345)).toBe('+12.35');
    expect(formatSigned(-1234.5)).toBe('−1,234.50');
    expect(formatSigned(0.001)).toBe('0.00');
    expect(signClass(-0.004)).toBe('flat');
    expect(signClass(-0.01)).toBe('neg');
  });

  it('formats percentages', () => {
    expect(formatPercent(0.1234)).toBe('+0.123%');
    expect(formatPercent(-0.0001)).toBe('0.000%');
  });
});
