const amount = new Intl.NumberFormat('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const wholeAmount = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 });
const MINUS = '−';

/** 5 dp, the precision rates are quoted to. */
export const formatRate = (rate: number): string => rate.toFixed(5);

/** 1,234.56 */
export const formatAmount = (value: number): string => amount.format(value).replace('-', MINUS);

/** 1,000 or 1,000.5 — for compact labels. */
export const formatCompactAmount = (value: number): string => wholeAmount.format(value);

/** +12.34 / −12.34 / 0.00, with a true minus sign so P&L never relies on colour alone. */
export function formatSigned(value: number): string {
  const rounded = Math.round(value * 100) / 100;
  if (rounded === 0) return amount.format(0);
  return `${rounded > 0 ? '+' : MINUS}${amount.format(Math.abs(rounded))}`;
}

/** +0.123% */
export function formatPercent(value: number, digits = 3): string {
  const fixed = Math.abs(value).toFixed(digits);
  if (Number(fixed) === 0) return `${(0).toFixed(digits)}%`;
  return `${value > 0 ? '+' : MINUS}${fixed}%`;
}

/** The CSS class for a value's sign. */
export const signClass = (value: number): 'pos' | 'neg' | 'flat' =>
  Math.round(value * 100) === 0 ? 'flat' : value > 0 ? 'pos' : 'neg';

/** 14:03:22 in the viewer's locale. */
export const formatTime = (iso: string): string =>
  new Date(iso).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
