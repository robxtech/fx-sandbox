import { describe, expect, it } from 'vitest';
import { mergeHistory } from './history';
import type { Rate, Snapshot } from './types';

const rate = (value: number, history: number[] | null = null): Rate => ({
  pair: 'USD/EUR',
  base: 'USD',
  quote: 'EUR',
  rate: value,
  previousRate: value,
  seedRate: value,
  changePercent: 0,
  history,
});

const snapshot = (tick: number, r: Rate): Snapshot =>
  ({ tick, rates: [r] }) as unknown as Snapshot;

describe('mergeHistory', () => {
  it('replaces history when the snapshot carries it', () => {
    const state = mergeHistory({ tick: 0, history: {} }, snapshot(5, rate(0.3, [0.1, 0.2, 0.3])));
    expect(state.history['USD/EUR']).toEqual([0.1, 0.2, 0.3]);
    expect(state.tick).toBe(5);
  });

  it('appends once per tick and ignores repeat snapshots on the same tick', () => {
    let state = mergeHistory({ tick: 0, history: {} }, snapshot(5, rate(0.3, [0.3])));
    state = mergeHistory(state, snapshot(6, rate(0.31)));
    state = mergeHistory(state, snapshot(6, rate(0.31)));
    state = mergeHistory(state, snapshot(7, rate(0.32)));
    expect(state.history['USD/EUR']).toEqual([0.3, 0.31, 0.32]);
  });

  it('starts a history from a tick snapshot that arrives before the full one', () => {
    const state = mergeHistory({ tick: 0, history: {} }, snapshot(9, rate(0.5)));
    expect(state.history['USD/EUR']).toEqual([0.5]);
  });

  it('keeps at most 180 points', () => {
    let state = mergeHistory({ tick: 0, history: {} }, snapshot(1, rate(1, Array.from({ length: 180 }, () => 1))));
    state = mergeHistory(state, snapshot(2, rate(2)));
    expect(state.history['USD/EUR']).toHaveLength(180);
    expect(state.history['USD/EUR']?.at(-1)).toBe(2);
  });
});
