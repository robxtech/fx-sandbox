import type { PlaceOrderRequest, PlaceOrderResult, Problem, Snapshot } from './types';

/** A failed API call, carrying the server's ProblemDetails. */
export class ApiError extends Error {
  readonly status: number;
  readonly problem: Problem;

  constructor(status: number, problem: Problem) {
    super(ApiError.describe(problem, status));
    this.name = 'ApiError';
    this.status = status;
    this.problem = problem;
  }

  /** The most useful plain-English message in a problem: detail, then field errors, then title. */
  static describe(problem: Problem, status: number): string {
    if (problem.detail) return problem.detail;
    const fieldErrors = Object.values(problem.errors ?? {}).flat();
    if (fieldErrors.length > 0) return fieldErrors.join(' ');
    return problem.title ?? `The request failed (${status}).`;
  }
}

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(url, {
      method,
      headers: body === undefined ? undefined : { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
  } catch {
    throw new ApiError(0, { title: "Can't reach the sandbox server. Check that the API is running." });
  }

  if (!response.ok) {
    const problem = (await response.json().catch(() => ({}))) as Problem;
    throw new ApiError(response.status, problem);
  }

  return response.status === 204 ? (undefined as T) : ((await response.json()) as T);
}

export const api = {
  snapshot: () => request<Snapshot>('GET', '/api/snapshot?history=true'),
  placeOrder: (order: PlaceOrderRequest) => request<PlaceOrderResult>('POST', '/api/orders', order),
  cancelOrder: (id: string) => request<void>('DELETE', `/api/orders/${encodeURIComponent(id)}`),
  reset: () => request<Snapshot>('POST', '/api/reset'),
};
