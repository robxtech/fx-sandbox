// Mirrors the server's snapshot records (FxSandbox.Core.Snapshots). Decimals arrive as JSON numbers.

export type Side = 'Buy' | 'Sell';
export type OrderStatus = 'Open' | 'Filled' | 'Cancelled';
export type SeedSource = 'Live' | 'Configured';

export interface Seed {
  source: SeedSource;
  description: string;
  asOf: string | null;
  seededAt: string;
}

export interface Rate {
  pair: string;
  base: string;
  quote: string;
  rate: number;
  previousRate: number;
  seedRate: number;
  changePercent: number;
  history: number[] | null;
}

export interface Order {
  id: string;
  pair: string;
  side: Side;
  quantity: number;
  limitPrice: number;
  status: OrderStatus;
  reservedCurrency: string;
  reservedAmount: number;
  createdAt: string;
  closedAt: string | null;
  fillPrice: number | null;
  quoteAmount: number | null;
}

export interface Fill {
  sequence: number;
  orderId: string;
  pair: string;
  side: Side;
  quantity: number;
  limitPrice: number;
  price: number;
  quoteAmount: number;
  realisedPnl: number | null;
  timestamp: string;
}

export interface Position {
  pair: string;
  currency: string;
  amount: number;
  costBasisUsd: number;
  averageRate: number | null;
  currentRate: number;
  marketValueUsd: number;
  unrealisedPnl: number;
  realisedPnl: number;
}

export interface Balance {
  currency: string;
  balance: number;
  reserved: number;
  available: number;
}

export interface Account {
  startingCapital: number;
  usdCash: number;
  accountValue: number;
  unrealisedPnl: number;
  realisedPnl: number;
}

export interface Snapshot {
  tick: number;
  timestamp: string;
  seed: Seed;
  rates: Rate[];
  orders: Order[];
  fills: Fill[];
  positions: Position[];
  balances: Balance[];
  account: Account;
}

export interface PlaceOrderRequest {
  pair: string;
  side: Side;
  quantity: number;
  limitPrice: number;
}

export interface PlaceOrderResult {
  order: Order;
  fill: Fill | null;
}

/** RFC 7807 problem details, as returned for every rejected request. */
export interface Problem {
  title?: string;
  detail?: string;
  status?: number;
  errors?: Record<string, string[]>;
}
