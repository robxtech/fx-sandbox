import { HubConnection, HubConnectionBuilder, HubConnectionState, LogLevel } from '@microsoft/signalr';
import { useCallback, useEffect, useRef, useState } from 'react';
import { mergeHistory, type MarketState } from './history';
import type { Fill, Snapshot } from './types';

export type ConnectionStatus = 'connecting' | 'live' | 'reconnecting' | 'offline';

const HUB_URL = '/hubs/sandbox';

/** Retries forever, backing off to 10 seconds, so the UI recovers when the API restarts. */
const retryPolicy = {
  nextRetryDelayInMilliseconds: ({ previousRetryCount }: { previousRetryCount: number }) =>
    Math.min(10_000, 500 * 2 ** previousRetryCount),
};

export interface SandboxState {
  snapshot: Snapshot | null;
  market: MarketState;
  status: ConnectionStatus;
  /** Apply a snapshot returned by a REST call (for example reset) without waiting for the next push. */
  applySnapshot: (snapshot: Snapshot) => void;
}

/**
 * Subscribes to the sandbox hub. The hub is push-only: it sends a snapshot with history on connect,
 * then a snapshot every tick and after every trader action. Calls onFills with fills not seen before.
 */
export function useSandbox(onFills: (fills: Fill[]) => void): SandboxState {
  const [snapshot, setSnapshot] = useState<Snapshot | null>(null);
  const [market, setMarket] = useState<MarketState>({ tick: 0, history: {} });
  const [status, setStatus] = useState<ConnectionStatus>('connecting');

  const lastFillSequence = useRef<number | null>(null);
  const onFillsRef = useRef(onFills);
  useEffect(() => {
    onFillsRef.current = onFills;
  }, [onFills]);

  const applySnapshot = useCallback((next: Snapshot) => {
    // Ignore a stale tick snapshot; snapshots carrying history (connect, reset) always apply.
    setSnapshot((current) => (current && next.tick < current.tick && !next.rates[0]?.history ? current : next));
    setMarket((current) => mergeHistory(current, next));

    const newest = next.fills.reduce((max, f) => Math.max(max, f.sequence), 0);
    if (lastFillSequence.current === null) {
      // First snapshot: fills that happened before we connected are history, not news.
      lastFillSequence.current = newest;
      return;
    }
    if (newest < lastFillSequence.current) {
      // The server restarted and its fill numbering began again.
      lastFillSequence.current = newest;
      return;
    }
    const seen = lastFillSequence.current;
    const fresh = next.fills.filter((f) => f.sequence > seen).sort((a, b) => a.sequence - b.sequence);
    if (fresh.length > 0) {
      lastFillSequence.current = newest;
      onFillsRef.current(fresh);
    }
  }, []);

  useEffect(() => {
    const connection: HubConnection = new HubConnectionBuilder()
      .withUrl(HUB_URL)
      .withAutomaticReconnect(retryPolicy)
      .configureLogging(LogLevel.Warning)
      .build();

    let disposed = false;
    let retryTimer: ReturnType<typeof setTimeout> | undefined;

    connection.on('snapshot', applySnapshot);
    connection.onreconnecting(() => setStatus('reconnecting'));
    connection.onreconnected(() => setStatus('live'));
    connection.onclose(() => {
      if (!disposed) {
        setStatus('offline');
        scheduleStart(2_000);
      }
    });

    function scheduleStart(delay: number) {
      retryTimer = setTimeout(start, delay);
    }

    async function start() {
      if (disposed || connection.state !== HubConnectionState.Disconnected) return;
      try {
        await connection.start();
        if (!disposed) setStatus('live');
      } catch {
        if (!disposed) {
          setStatus('offline');
          scheduleStart(3_000);
        }
      }
    }

    void start();

    return () => {
      disposed = true;
      clearTimeout(retryTimer);
      void connection.stop();
    };
  }, [applySnapshot]);

  return { snapshot, market, status, applySnapshot };
}
