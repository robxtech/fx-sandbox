import type { Snapshot } from './types';

export const HISTORY_LENGTH = 180;

export type RateHistory = Record<string, number[]>;

export interface MarketState {
  tick: number;
  history: RateHistory;
}

/**
 * Folds a snapshot into the client's rate history.
 * Snapshots with history (on connect and after reset) replace it; tick snapshots append the latest rate once per tick.
 * Snapshots pushed after trader actions share the current tick, so they never add a duplicate point.
 */
export function mergeHistory(state: MarketState, snapshot: Snapshot): MarketState {
  const history: RateHistory = { ...state.history };
  const isNewTick = snapshot.tick > state.tick;

  for (const rate of snapshot.rates) {
    if (rate.history) {
      history[rate.pair] = rate.history.slice(-HISTORY_LENGTH);
    } else {
      const previous = history[rate.pair] ?? [];
      if (previous.length === 0) history[rate.pair] = [rate.rate];
      else if (isNewTick) history[rate.pair] = [...previous, rate.rate].slice(-HISTORY_LENGTH);
    }
  }

  const replaced = snapshot.rates.some((r) => r.history);
  return { tick: replaced ? snapshot.tick : Math.max(state.tick, snapshot.tick), history };
}
