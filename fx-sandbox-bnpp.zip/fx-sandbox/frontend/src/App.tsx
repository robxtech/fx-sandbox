import { useCallback, useEffect, useReducer, useRef, useState } from 'react';
import { ApiError, api } from './api/client';
import type { Fill, Order, PlaceOrderResult } from './api/types';
import { useSandbox } from './api/useSandbox';
import { CashPanel } from './components/CashPanel';
import { Header } from './components/Header';
import { OrderBook } from './components/OrderBook';
import { OrderTicket } from './components/OrderTicket';
import { PairChart } from './components/PairChart';
import { Positions } from './components/Positions';
import { Toasts, type Toast } from './components/Toasts';
import { formatAmount, formatRate, formatSigned } from './lib/format';
import { quoteOf } from './lib/orders';
import { initialTicket, ticketReducer } from './lib/ticket';
import { useTheme } from './useTheme';

const TOAST_MS = 6000;

function describeFill(fill: Fill): Omit<Toast, 'id'> {
  const quote = quoteOf(fill.pair);
  const body =
    fill.side === 'Sell'
      ? `Sold ${formatAmount(fill.quantity)} USD at ${formatRate(fill.price)} and received ${formatAmount(fill.quoteAmount)} ${quote}.`
      : `Bought ${formatAmount(fill.quantity)} USD at ${formatRate(fill.price)} for ${formatAmount(fill.quoteAmount)} ${quote}. Realised ${formatSigned(fill.realisedPnl ?? 0)} USD.`;
  return { tone: fill.side === 'Sell' ? 'sell' : 'buy', title: `Filled: ${fill.side.toLowerCase()} ${fill.pair}`, body };
}

export default function App() {
  const [theme, toggleTheme] = useTheme();
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [cancelling, setCancelling] = useState<ReadonlySet<string>>(new Set());
  const [ticket, dispatch] = useReducer(ticketReducer, initialTicket);
  const nextToastId = useRef(1);
  const ticketRef = useRef<HTMLDivElement>(null);

  const dismiss = useCallback((id: number) => setToasts((all) => all.filter((t) => t.id !== id)), []);

  const notify = useCallback(
    (toast: Omit<Toast, 'id'>) => {
      const id = nextToastId.current++;
      setToasts((all) => [...all.slice(-4), { ...toast, id }]);
      setTimeout(() => dismiss(id), TOAST_MS);
    },
    [dismiss],
  );

  const onFills = useCallback((fills: Fill[]) => fills.forEach((f) => notify(describeFill(f))), [notify]);
  const { snapshot, market, status, applySnapshot } = useSandbox(onFills);

  // Keep the page title useful when the tab is in the background.
  useEffect(() => {
    if (snapshot) document.title = `${formatAmount(snapshot.account.accountValue)} USD · FX sandbox`;
  }, [snapshot]);

  function onPlaced(result: PlaceOrderResult) {
    // Immediate fills arrive as fill toasts via the hub; resting orders get a placement note.
    if (!result.fill) {
      const o = result.order;
      notify({ tone: 'info', title: 'Order placed', body: `${o.side} ${formatAmount(o.quantity)} USD on ${o.pair} at ${formatRate(o.limitPrice)}.` });
    }
  }

  async function cancel(order: Order) {
    setCancelling((s) => new Set(s).add(order.id));
    try {
      await api.cancelOrder(order.id);
      notify({ tone: 'info', title: 'Order cancelled', body: `${order.side} ${formatAmount(order.quantity)} USD on ${order.pair}. Funds released.` });
    } catch (error) {
      notify({ tone: 'error', title: "Couldn't cancel the order", body: error instanceof ApiError ? error.message : undefined });
    } finally {
      setCancelling((s) => {
        const next = new Set(s);
        next.delete(order.id);
        return next;
      });
    }
  }

  async function reset() {
    try {
      const fresh = await api.reset();
      applySnapshot(fresh);
      notify({ tone: 'info', title: 'Sandbox reset', body: `Back to ${formatAmount(fresh.account.startingCapital)} USD with no orders or positions.` });
    } catch (error) {
      notify({ tone: 'error', title: "Couldn't reset the sandbox", body: error instanceof ApiError ? error.message : undefined });
    }
  }

  function pick(pair: string, price: number) {
    dispatch({ type: 'pick', pair, price });
    // On narrow screens the ticket sits below the charts; bring it into view.
    if (window.matchMedia('(max-width: 1023px)').matches) {
      ticketRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  const rates = snapshot?.rates ?? [];
  const openOrders = snapshot?.orders.filter((o) => o.status === 'Open') ?? [];

  return (
    <>
      <a className="skip-link" href="#ticket">Skip to the order ticket</a>
      <Header
        account={snapshot?.account ?? null}
        seed={snapshot?.seed ?? null}
        status={status}
        theme={theme}
        onToggleTheme={toggleTheme}
        onReset={reset}
      />

      {!snapshot ? (
        <main className="loading" aria-busy="true">
          <p>{status === 'offline' ? "Can't reach the sandbox server. Retrying…" : 'Connecting to the sandbox…'}</p>
        </main>
      ) : (
        <main className="layout">
          <section className="charts" aria-label="Live rates">
            {rates.map((r) => (
              <PairChart
                key={r.pair}
                rate={r}
                history={market.history[r.pair] ?? []}
                orders={openOrders.filter((o) => o.pair === r.pair)}
                selected={ticket.pair === r.pair}
                onSelect={(pair) => dispatch({ type: 'pair', pair })}
                onPick={pick}
              />
            ))}
          </section>

          <div className="side" id="ticket" ref={ticketRef}>
            <OrderTicket state={ticket} dispatch={dispatch} rates={rates} balances={snapshot.balances} onPlaced={onPlaced} />
            <CashPanel balances={snapshot.balances} />
          </div>

          <div className="lower">
            <OrderBook orders={snapshot.orders} rates={rates} cancelling={cancelling} onCancel={cancel} />
            <Positions positions={snapshot.positions} />
          </div>
        </main>
      )}

      <Toasts toasts={toasts} onDismiss={dismiss} />
    </>
  );
}
