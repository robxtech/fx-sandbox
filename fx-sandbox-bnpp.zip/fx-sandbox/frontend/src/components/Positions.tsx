import { useId } from 'react';
import type { Position } from '../api/types';
import { formatAmount, formatRate, formatSigned, signClass } from '../lib/format';

export function Positions({ positions }: { positions: Position[] }) {
  const titleId = useId();
  const visible = positions.filter((p) => p.amount !== 0 || p.realisedPnl !== 0);

  return (
    <section className="panel positions" aria-labelledby={titleId}>
      <div className="panel-head">
        <h2 id={titleId} className="panel-title">Positions</h2>
        <p className="panel-note">Marked to the latest simulated rate. Unrealised P&amp;L = holding ÷ current rate − cost.</p>
      </div>
      <div className="table-wrap">
        {visible.length === 0 ? (
          <p className="empty">No positions yet. Selling USD for EUR, GBP or CHF opens one.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Holding</th>
                <th scope="col" className="r">Avg rate</th>
                <th scope="col" className="r">Current rate</th>
                <th scope="col" className="r">Cost (USD)</th>
                <th scope="col" className="r">Value (USD)</th>
                <th scope="col" className="r">Unrealised P&amp;L</th>
                <th scope="col" className="r">Realised P&amp;L</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((p) => (
                <tr key={p.pair}>
                  <th scope="row" className="holding">
                    <span className="num">{formatAmount(p.amount)}</span> <span className="ccy">{p.currency}</span>
                    <span className="pair-name">{p.pair}</span>
                  </th>
                  <td className="r num">{p.averageRate === null ? '—' : formatRate(p.averageRate)}</td>
                  <td className="r num">{formatRate(p.currentRate)}</td>
                  <td className="r num">{formatAmount(p.costBasisUsd)}</td>
                  <td className="r num">{formatAmount(p.marketValueUsd)}</td>
                  <td className={`r num pnl ${signClass(p.unrealisedPnl)}`}>{formatSigned(p.unrealisedPnl)}</td>
                  <td className={`r num pnl ${signClass(p.realisedPnl)}`}>{formatSigned(p.realisedPnl)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </section>
  );
}
