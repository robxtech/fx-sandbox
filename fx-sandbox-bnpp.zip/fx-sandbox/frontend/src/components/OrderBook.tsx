import { useId, useState } from 'react';
import type { Order, Rate } from '../api/types';
import { formatAmount, formatRate, formatTime } from '../lib/format';
import { distanceToFill, proximity, quoteOf } from '../lib/orders';

interface OrderBookProps {
  orders: Order[];
  rates: Rate[];
  cancelling: ReadonlySet<string>;
  onCancel: (order: Order) => void;
}

type Tab = 'open' | 'closed';

export function OrderBook({ orders, rates, cancelling, onCancel }: OrderBookProps) {
  const [tab, setTab] = useState<Tab>('open');
  const titleId = useId();
  const open = orders.filter((o) => o.status === 'Open');
  const closed = orders.filter((o) => o.status !== 'Open');
  const spotOf = (pair: string) => rates.find((r) => r.pair === pair)?.rate;

  return (
    <section className="panel book" aria-labelledby={titleId}>
      <div className="panel-head">
        <h2 id={titleId} className="panel-title">Order book</h2>
        <div className="tabs" role="tablist" aria-label="Orders">
          <button type="button" role="tab" id={`${titleId}-open`} aria-selected={tab === 'open'} aria-controls={`${titleId}-panel`} className="tab" onClick={() => setTab('open')}>
            Open <span className="count">{open.length}</span>
          </button>
          <button type="button" role="tab" id={`${titleId}-closed`} aria-selected={tab === 'closed'} aria-controls={`${titleId}-panel`} className="tab" onClick={() => setTab('closed')}>
            Filled and cancelled <span className="count">{closed.length}</span>
          </button>
        </div>
      </div>

      <div id={`${titleId}-panel`} role="tabpanel" aria-labelledby={`${titleId}-${tab}`} className="table-wrap">
        {tab === 'open' ? (
          open.length === 0 ? (
            <p className="empty">No open orders. Place one with the ticket, or click a chart to start at a rate.</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">Order</th>
                  <th scope="col" className="r">Amount</th>
                  <th scope="col" className="r">Limit</th>
                  <th scope="col" className="r">Spot</th>
                  <th scope="col">Distance to fill</th>
                  <th scope="col" className="r">Reserved</th>
                  <th scope="col"><span className="sr-only">Actions</span></th>
                </tr>
              </thead>
              <tbody>
                {open.map((o) => {
                  const spot = spotOf(o.pair) ?? o.limitPrice;
                  const distance = Math.max(0, distanceToFill(o.side, spot, o.limitPrice));
                  const closeness = proximity(distance);
                  return (
                    <tr key={o.id}>
                      <td><SideTag order={o} /></td>
                      <td className="r num">{formatAmount(o.quantity)} <span className="ccy">USD</span></td>
                      <td className="r num">{formatRate(o.limitPrice)}</td>
                      <td className="r num muted">{formatRate(spot)}</td>
                      <td>
                        <div className="distance">
                          <div className="distance-track" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(closeness * 100)} aria-label={`${(distance * 100).toFixed(3)}% to go`}>
                            <div className={`distance-fill ${o.side === 'Sell' ? 'sell' : 'buy'}`} style={{ width: `${Math.max(3, closeness * 100)}%` }} />
                          </div>
                          <span className="num muted distance-text">
                            {distance === 0 ? 'At limit' : `${(distance * 100).toFixed(3)}% ${o.side === 'Sell' ? 'rise' : 'fall'}`}
                          </span>
                        </div>
                      </td>
                      <td className="r num muted">
                        {formatAmount(o.reservedAmount)} <span className="ccy">{o.reservedCurrency}</span>
                      </td>
                      <td className="r">
                        <button type="button" className="button small ghost" disabled={cancelling.has(o.id)} onClick={() => onCancel(o)}>
                          {cancelling.has(o.id) ? 'Cancelling…' : 'Cancel'}
                          <span className="sr-only"> {o.side.toLowerCase()} {formatAmount(o.quantity)} USD at {formatRate(o.limitPrice)}</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )
        ) : closed.length === 0 ? (
          <p className="empty">Nothing filled or cancelled yet.</p>
        ) : (
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Order</th>
                <th scope="col">Status</th>
                <th scope="col" className="r">Amount</th>
                <th scope="col" className="r">Limit</th>
                <th scope="col" className="r">Filled at</th>
                <th scope="col" className="r">Received / paid</th>
                <th scope="col" className="r">Time</th>
              </tr>
            </thead>
            <tbody>
              {closed.map((o) => (
                <tr key={o.id}>
                  <td><SideTag order={o} /></td>
                  <td><span className={`status ${o.status.toLowerCase()}`}>{o.status}</span></td>
                  <td className="r num">{formatAmount(o.quantity)} <span className="ccy">USD</span></td>
                  <td className="r num">{formatRate(o.limitPrice)}</td>
                  <td className="r num">{o.fillPrice === null ? '—' : formatRate(o.fillPrice)}</td>
                  <td className="r num">
                    {o.quoteAmount === null ? '—' : (
                      <>
                        {o.side === 'Sell' ? '+' : '−'}{formatAmount(o.quoteAmount)} <span className="ccy">{quoteOf(o.pair)}</span>
                      </>
                    )}
                  </td>
                  <td className="r num muted">{o.closedAt ? formatTime(o.closedAt) : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </section>
  );
}

function SideTag({ order }: { order: Order }) {
  return (
    <span className="order-cell">
      <span className={`side-tag ${order.side === 'Sell' ? 'sell' : 'buy'}`}>{order.side}</span>
      <span className="pair-name">{order.pair}</span>
    </span>
  );
}
