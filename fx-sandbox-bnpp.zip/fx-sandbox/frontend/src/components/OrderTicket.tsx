import { useId, useState, type Dispatch, type FormEvent } from 'react';
import { ApiError, api } from '../api/client';
import type { Balance, PlaceOrderResult, Rate, Side } from '../api/types';
import { formatAmount, formatRate } from '../lib/format';
import {
  describeFill,
  isMarketable,
  maxQuantity,
  quoteOf,
  ticketFlows,
  validateLimit,
  validateQuantity,
} from '../lib/orders';
import { effectiveLimit, type TicketAction, type TicketState } from '../lib/ticket';

interface OrderTicketProps {
  state: TicketState;
  dispatch: Dispatch<TicketAction>;
  rates: Rate[];
  balances: Balance[];
  onPlaced: (result: PlaceOrderResult) => void;
}

const QUICK_AMOUNTS = [1000, 2500, 5000];

export function OrderTicket({ state, dispatch, rates, balances, onPlaced }: OrderTicketProps) {
  const [submitting, setSubmitting] = useState(false);
  const [serverError, setServerError] = useState<string | null>(null);
  const ids = { title: useId(), amount: useId(), limit: useId(), hint: useId(), status: useId() };

  const rate = rates.find((r) => r.pair === state.pair);
  const spot = rate?.rate;
  const quote = quoteOf(state.pair);
  const limitText = effectiveLimit(state, spot);

  const amountError = validateQuantity(state.amount);
  const limitError = validateLimit(limitText);
  const quantity = Number(state.amount);
  const limit = Number(limitText);
  const valid = !amountError && !limitError && spot !== undefined;

  const flows = valid ? ticketFlows(state.pair, state.side, quantity, limit) : null;
  const reserveCurrency = state.side === 'Sell' ? 'USD' : quote;
  const available = balances.find((b) => b.currency === reserveCurrency)?.available ?? 0;
  const shortBy = flows && flows.reserve.amount > available + 1e-9;
  const fundsMessage = shortBy
    ? `Not enough ${reserveCurrency}: this order needs ${formatAmount(flows.reserve.amount)} and ${formatAmount(available)} is available.`
    : null;

  const marketable = valid && isMarketable(state.side, spot, limit);
  const canSubmit = valid && !shortBy && !submitting;

  function setSide(side: Side) {
    setServerError(null);
    dispatch({ type: 'side', side });
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setServerError(null);
    try {
      const result = await api.placeOrder({ pair: state.pair, side: state.side, quantity, limitPrice: limit });
      onPlaced(result);
    } catch (error) {
      setServerError(error instanceof ApiError ? error.message : 'Something went wrong placing the order.');
    } finally {
      setSubmitting(false);
    }
  }

  const sideClass = state.side === 'Sell' ? 'sell' : 'buy';

  return (
    <section className="panel ticket" aria-labelledby={ids.title}>
      <h2 id={ids.title} className="panel-title">New limit order</h2>

      <form onSubmit={submit} noValidate>
        <fieldset className="field">
          <legend className="field-label">Pair</legend>
          <div className="segmented" role="radiogroup" aria-label="Pair">
            {rates.map((r) => (
              <button
                key={r.pair}
                type="button"
                role="radio"
                aria-checked={r.pair === state.pair}
                className="segment"
                onClick={() => dispatch({ type: 'pair', pair: r.pair })}
              >
                {r.pair}
              </button>
            ))}
          </div>
        </fieldset>

        <fieldset className="field">
          <legend className="field-label">Side</legend>
          <div className="side-toggle" role="radiogroup" aria-label="Side">
            <button type="button" role="radio" aria-checked={state.side === 'Sell'} className="side-option sell" onClick={() => setSide('Sell')}>
              <strong>Sell USD</strong> <span>/ receive {quote}</span>
            </button>
            <button type="button" role="radio" aria-checked={state.side === 'Buy'} className="side-option buy" onClick={() => setSide('Buy')}>
              <strong>Buy USD</strong> <span>/ pay with {quote}</span>
            </button>
          </div>
        </fieldset>

        <div className="field">
          <label className="field-label" htmlFor={ids.amount}>Amount in USD</label>
          <input
            id={ids.amount}
            className="input num"
            inputMode="decimal"
            autoComplete="off"
            value={state.amount}
            onChange={(e) => dispatch({ type: 'amount', amount: e.target.value.replace(/,/g, '') })}
            aria-invalid={amountError ? true : undefined}
            aria-describedby={amountError ? `${ids.amount}-error` : undefined}
          />
          <div className="chips">
            {QUICK_AMOUNTS.map((a) => (
              <button key={a} type="button" className="chip" onClick={() => dispatch({ type: 'amount', amount: String(a) })}>
                {a.toLocaleString('en-US')}
              </button>
            ))}
            <button
              type="button"
              className="chip"
              disabled={!(limit > 0)}
              onClick={() => dispatch({ type: 'amount', amount: maxQuantity(state.side, available, limit).toFixed(2) })}
            >
              Max
            </button>
          </div>
          {amountError && <p id={`${ids.amount}-error`} className="field-error">{amountError}</p>}
        </div>

        <div className="field">
          <div className="field-label-row">
            <label className="field-label" htmlFor={ids.limit}>Limit rate <span className="muted">({quote} per USD)</span></label>
            {state.following ? (
              <span className="following"><span className="pulse" aria-hidden="true" />Following market</span>
            ) : (
              <button type="button" className="link-button" onClick={() => dispatch({ type: 'follow' })}>
                Follow market
              </button>
            )}
          </div>
          <div className="stepper">
            <button type="button" className="step" aria-label="Lower the limit by 1 pip" disabled={spot === undefined} onClick={() => spot !== undefined && dispatch({ type: 'nudge', pips: -1, spot })}>
              −1 pip
            </button>
            <input
              id={ids.limit}
              className="input num"
              inputMode="decimal"
              autoComplete="off"
              value={limitText}
              onChange={(e) => dispatch({ type: 'limit', limit: e.target.value })}
              aria-invalid={limitError ? true : undefined}
              aria-describedby={limitError ? `${ids.limit}-error` : ids.hint}
            />
            <button type="button" className="step" aria-label="Raise the limit by 1 pip" disabled={spot === undefined} onClick={() => spot !== undefined && dispatch({ type: 'nudge', pips: 1, spot })}>
              +1 pip
            </button>
          </div>
          {limitError && <p id={`${ids.limit}-error`} className="field-error">{limitError}</p>}
          {spot !== undefined && <p id={ids.hint} className="field-hint">Spot is <span className="num">{formatRate(spot)}</span>. Tip: click a chart to set the limit there.</p>}
        </div>

        {flows && (
          <dl className="summary">
            <div>
              <dt>You pay</dt>
              <dd className="num">
                {state.side === 'Buy' && <span className="muted">at most </span>}
                {formatAmount(flows.pay.amount)} <span className="ccy">{flows.pay.currency}</span>
              </dd>
            </div>
            <div>
              <dt>You receive</dt>
              <dd className="num">
                {state.side === 'Sell' && <span className="muted">at least </span>}
                {formatAmount(flows.receive.amount)} <span className="ccy">{flows.receive.currency}</span>
              </dd>
            </div>
            <div>
              <dt>Available</dt>
              <dd className="num">
                {formatAmount(available)} <span className="ccy">{reserveCurrency}</span>
              </dd>
            </div>
          </dl>
        )}

        <div id={ids.status} className="ticket-status" role="status">
          {valid && (
            <p className={`fill-line${marketable ? ' now' : ''}`}>
              <span className="fill-icon" aria-hidden="true">{marketable ? '⚡' : state.side === 'Sell' ? '↗' : '↘'}</span>
              {describeFill(state.pair, state.side, limit, spot)}
            </p>
          )}
          {fundsMessage && <p className="field-error">{fundsMessage}</p>}
          {serverError && <p className="field-error">{serverError}</p>}
        </div>

        <button type="submit" className={`submit ${sideClass}`} disabled={!canSubmit}>
          {submitting
            ? 'Placing order…'
            : valid
              ? `${state.side} ${formatAmount(quantity)} USD at ${formatRate(limit)}`
              : `Place ${state.side.toLowerCase()} order`}
        </button>
      </form>
    </section>
  );
}
