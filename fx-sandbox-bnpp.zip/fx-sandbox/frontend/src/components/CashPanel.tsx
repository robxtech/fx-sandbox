import { useId } from 'react';
import type { Balance } from '../api/types';
import { formatAmount } from '../lib/format';

export function CashPanel({ balances }: { balances: Balance[] }) {
  const titleId = useId();
  return (
    <section className="panel cash" aria-labelledby={titleId}>
      <h2 id={titleId} className="panel-title">Cash</h2>
      <ul className="cash-list">
        {balances.map((b) => {
          const reservedShare = b.balance > 0 ? b.reserved / b.balance : 0;
          return (
            <li key={b.currency} className={b.balance === 0 ? 'is-empty' : undefined}>
              <div className="cash-row">
                <span className="ccy-code">{b.currency}</span>
                <span className="num cash-balance">{formatAmount(b.balance)}</span>
              </div>
              <div className="cash-bar" aria-hidden="true">
                <div className="cash-bar-reserved" style={{ width: `${reservedShare * 100}%` }} />
              </div>
              <div className="cash-row small muted">
                <span>On orders <span className="num">{formatAmount(b.reserved)}</span></span>
                <span>Available <span className="num">{formatAmount(b.available)}</span></span>
              </div>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
