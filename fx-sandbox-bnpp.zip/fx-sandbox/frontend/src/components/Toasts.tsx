export interface Toast {
  id: number;
  tone: 'sell' | 'buy' | 'info' | 'error';
  title: string;
  body?: string;
}

export function Toasts({ toasts, onDismiss }: { toasts: Toast[]; onDismiss: (id: number) => void }) {
  return (
    <div className="toasts" aria-live="polite" aria-relevant="additions">
      {toasts.map((t) => (
        <div key={t.id} className={`toast ${t.tone}`} role={t.tone === 'error' ? 'alert' : undefined}>
          <div className="toast-text">
            <p className="toast-title">{t.title}</p>
            {t.body && <p className="toast-body num">{t.body}</p>}
          </div>
          <button type="button" className="toast-close" onClick={() => onDismiss(t.id)} aria-label="Dismiss">
            ×
          </button>
        </div>
      ))}
    </div>
  );
}
