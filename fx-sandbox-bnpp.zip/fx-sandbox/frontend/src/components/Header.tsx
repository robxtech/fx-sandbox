import { useEffect, useState } from 'react';
import type { ConnectionStatus } from '../api/useSandbox';
import type { Account, Seed } from '../api/types';
import { formatAmount, formatSigned, signClass } from '../lib/format';

interface HeaderProps {
  account: Account | null;
  seed: Seed | null;
  status: ConnectionStatus;
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  onReset: () => Promise<void>;
}

const STATUS_LABEL: Record<ConnectionStatus, string> = {
  connecting: 'Connecting',
  live: 'Live',
  reconnecting: 'Reconnecting',
  offline: 'Offline',
};

/** "Seeded from ECB rates of 25 Sep 2026" or "Seeded from configured rates (live rates were unavailable)". */
function describeSeed(seed: Seed): string {
  if (seed.source === 'Live') {
    const date = seed.asOf
      ? new Date(`${seed.asOf}T00:00:00`).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })
      : null;
    return date ? `Seeded from ECB rates of ${date}.` : 'Seeded from live ECB rates.';
  }
  const reason = /\((.+)\)/.exec(seed.description)?.[1];
  return reason ? `Seeded from configured rates (${reason}).` : 'Seeded from configured rates.';
}

export function Header({ account, seed, status, theme, onToggleTheme, onReset }: HeaderProps) {
  const [confirming, setConfirming] = useState(false);
  const [resetting, setResetting] = useState(false);

  // A second click within a few seconds confirms the reset; otherwise the button reverts.
  useEffect(() => {
    if (!confirming) return;
    const timer = setTimeout(() => setConfirming(false), 4000);
    return () => clearTimeout(timer);
  }, [confirming]);

  async function reset() {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    setConfirming(false);
    setResetting(true);
    try {
      await onReset();
    } finally {
      setResetting(false);
    }
  }

  const pnl = account ? account.accountValue - account.startingCapital : 0;

  return (
    <header className="app-header">
      <div className="brand">
        <svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true" className="brand-mark">
          <rect width="32" height="32" rx="7" />
          <path d="M5 21l6-6 5 4 11-10" className="brand-line" />
          <path d="M5 11h22" className="brand-limit" />
        </svg>
        <div>
          <h1 className="brand-name">FX sandbox</h1>
          <p className="brand-sub">
            Limit orders on simulated rates.{' '}
            {seed && (
              <span className={`seed ${seed.source.toLowerCase()}`} title={seed.description}>
                {describeSeed(seed)}
              </span>
            )}
          </p>
        </div>
      </div>

      <dl className="metrics" aria-label="Account">
        <div className="metric hero">
          <dt>Account value</dt>
          <dd className="num">
            {account ? formatAmount(account.accountValue) : '—'} <span className="ccy">USD</span>
            {account && signClass(pnl) !== 'flat' && (
              <span className={`delta ${signClass(pnl)}`} title="Change since the start">{formatSigned(pnl)}</span>
            )}
          </dd>
        </div>
        <div className="metric">
          <dt>Unrealised P&amp;L</dt>
          <dd className={`num pnl ${account ? signClass(account.unrealisedPnl) : ''}`}>{account ? formatSigned(account.unrealisedPnl) : '—'}</dd>
        </div>
        <div className="metric">
          <dt>Realised P&amp;L</dt>
          <dd className={`num pnl ${account ? signClass(account.realisedPnl) : ''}`}>{account ? formatSigned(account.realisedPnl) : '—'}</dd>
        </div>
        <div className="metric">
          <dt>Starting capital</dt>
          <dd className="num">{account ? formatAmount(account.startingCapital) : '—'}</dd>
        </div>
      </dl>

      <div className="header-actions">
        <span className={`status-pill ${status}`} role="status" aria-live="polite">
          <span className="status-dot" aria-hidden="true" />
          {STATUS_LABEL[status]}
        </span>
        <button type="button" className="button ghost icon-button" onClick={onToggleTheme} aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}>
          <span aria-hidden="true">{theme === 'dark' ? '☀' : '☾'}</span>
        </button>
        <button type="button" className={`button ${confirming ? 'danger' : 'ghost'}`} onClick={reset} disabled={resetting || !account}>
          {resetting ? 'Resetting…' : confirming ? 'Confirm reset' : 'Reset'}
        </button>
      </div>
    </header>
  );
}
