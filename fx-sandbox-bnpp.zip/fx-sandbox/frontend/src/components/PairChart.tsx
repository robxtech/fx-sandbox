import { useId, useMemo, useState, type KeyboardEvent, type MouseEvent } from 'react';
import { HISTORY_LENGTH } from '../api/history';
import type { Order, Rate } from '../api/types';
import { formatCompactAmount, formatPercent, formatRate } from '../lib/format';
import { NEAR_BAND, PIP, distanceToFill, roundRate } from '../lib/orders';
import { useElementWidth } from './useElementWidth';

interface PairChartProps {
  rate: Rate;
  history: number[];
  orders: Order[];
  selected: boolean;
  onSelect: (pair: string) => void;
  /** Called when the trader clicks the chart: pre-fills the order ticket at that rate. */
  onPick: (pair: string, price: number) => void;
}

const HEIGHT = 196;
const M = { top: 22, right: 76, bottom: 10, left: 8 };
const LABEL_H = 16;
const NICE_STEPS = [0.00002, 0.00005, 0.0001, 0.0002, 0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05];

function niceTicks(lo: number, hi: number, target = 4): number[] {
  const raw = (hi - lo) / target;
  const step = NICE_STEPS.find((s) => s >= raw) ?? raw;
  const ticks: number[] = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-12; v += step) ticks.push(roundRate(v));
  return ticks;
}

/** Nudges label centres apart so they never overlap, keeping them inside [min, max]. */
function spreadLabels(ys: number[], min: number, max: number): number[] {
  const order = ys.map((y, i) => ({ y, i })).sort((a, b) => a.y - b.y);
  const placed: number[] = new Array<number>(ys.length);
  let last = -Infinity;
  for (const { y, i } of order) {
    const next = Math.min(max, Math.max(y, last + LABEL_H + 2, min));
    placed[i] = next;
    last = next;
  }
  return placed;
}

/**
 * The signature element: a live rate trace with the spot tag and every resting order drawn at its limit.
 * Orders more than 0.5% away are pinned to the top or bottom edge with an arrow. Hover shows a crosshair
 * with the rate under the cursor; clicking sends that rate to the order ticket.
 */
export function PairChart({ rate, history, orders, selected, onSelect, onPick }: PairChartProps) {
  const [containerRef, width] = useElementWidth<HTMLDivElement>();
  const [hoverY, setHoverY] = useState<number | null>(null);
  const gradientId = useId();
  const titleId = useId();

  const spot = rate.rate;
  const points = useMemo(() => (history.length > 0 ? history : [spot]), [history, spot]);
  const plotW = width - M.left - M.right;
  const plotH = HEIGHT - M.top - M.bottom;

  const { near, above, below } = useMemo(() => {
    const near: Order[] = [];
    const above: Order[] = [];
    const below: Order[] = [];
    for (const o of orders) {
      const gap = o.limitPrice / spot - 1;
      if (Math.abs(gap) <= NEAR_BAND) near.push(o);
      else (gap > 0 ? above : below).push(o);
    }
    return { near, above, below };
  }, [orders, spot]);

  // The y-domain covers the trace, the spot and every near order, with a minimum span of a few pips.
  const [lo, hi] = useMemo(() => {
    const values = [...points, spot, ...near.map((o) => o.limitPrice)];
    let min = Math.min(...values);
    let max = Math.max(...values);
    const minSpan = Math.max(spot * 0.0008, 4 * PIP);
    if (max - min < minSpan) {
      const mid = (max + min) / 2;
      min = mid - minSpan / 2;
      max = mid + minSpan / 2;
    }
    const pad = (max - min) * 0.12;
    return [min - pad, max + pad];
  }, [points, spot, near]);

  const y = (v: number) => M.top + ((hi - v) / (hi - lo)) * plotH;
  const step = plotW / (HISTORY_LENGTH - 1);
  const x = (i: number) => M.left + plotW - (points.length - 1 - i) * step;

  const line = points.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('');
  const area = `${line}L${x(points.length - 1).toFixed(1)},${M.top + plotH}L${x(0).toFixed(1)},${M.top + plotH}Z`;
  const ticks = niceTicks(lo, hi);

  const nearLabelYs = spreadLabels(near.map((o) => y(o.limitPrice)), M.top + LABEL_H / 2, M.top + plotH - LABEL_H / 2);

  const up = spot >= rate.previousRate;
  const priceAt = (py: number) => roundRate(hi - ((py - M.top) / plotH) * (hi - lo));
  const hoverPrice = hoverY === null ? null : priceAt(hoverY);

  function pointerY(event: MouseEvent<SVGSVGElement>) {
    const box = event.currentTarget.getBoundingClientRect();
    const py = event.clientY - box.top;
    return Math.min(M.top + plotH, Math.max(M.top, py));
  }

  function onKeyDown(event: KeyboardEvent<SVGSVGElement>) {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onPick(rate.pair, spot);
    }
  }

  const quote = rate.quote;
  const summary =
    `${rate.pair} at ${formatRate(spot)}, ${formatPercent(rate.changePercent)} since the seed. ` +
    `${orders.length} open order${orders.length === 1 ? '' : 's'}.`;

  return (
    <article className={`chart-card${selected ? ' is-selected' : ''}`} aria-labelledby={titleId}>
      <header className="chart-head">
        <button type="button" className="chart-title" onClick={() => onSelect(rate.pair)} aria-pressed={selected}>
          <span id={titleId} className="pair">{rate.pair}</span>
          <span className="chart-sub">1 USD in {quote}</span>
        </button>
        <div className="chart-quote">
          <span className={`spot num ${up ? 'up' : 'down'}`} aria-live="off">
            {formatRate(spot)}
            <span className="tick-arrow" aria-hidden="true">{up ? '▲' : '▼'}</span>
          </span>
          <span className="chart-change num">{formatPercent(rate.changePercent)} since seed</span>
        </div>
      </header>

      <div ref={containerRef} className="chart-frame">
        <svg
          width={width}
          height={HEIGHT}
          viewBox={`0 0 ${width} ${HEIGHT}`}
          role="img"
          aria-label={`${summary} Click the chart to set a limit rate.`}
          tabIndex={0}
          className="chart-svg"
          onPointerMove={(e) => setHoverY(pointerY(e))}
          onPointerLeave={() => setHoverY(null)}
          onClick={(e) => onPick(rate.pair, priceAt(pointerY(e)))}
          onKeyDown={onKeyDown}
        >
          <defs>
            <linearGradient id={gradientId} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="var(--trace)" stopOpacity="0.22" />
              <stop offset="100%" stopColor="var(--trace)" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Grid: recessive, labelled on the right. */}
          {ticks.map((t) => (
            <g key={t} className="grid">
              <line x1={M.left} x2={M.left + plotW} y1={y(t)} y2={y(t)} />
              {/* Skip labels the spot tag or crosshair tag would cover. */}
              {Math.abs(y(t) - y(spot)) > 14 && (hoverY === null || Math.abs(y(t) - hoverY) > 14) && (
                <text x={width - 6} y={y(t)} dy="0.32em" textAnchor="end" className="axis-label">
                  {t.toFixed(4)}
                </text>
              )}
            </g>
          ))}

          {/* Rate trace. */}
          <path d={area} fill={`url(#${gradientId})`} />
          <path d={line} className="trace" />
          <circle cx={x(points.length - 1)} cy={y(spot)} r={3.5} className="trace-dot" />

          {/* Resting orders within the band: a dashed line at the limit with a direct label. */}
          {near.map((o, i) => {
            const side = o.side === 'Sell' ? 'sell' : 'buy';
            const ly = nearLabelYs[i] ?? y(o.limitPrice);
            const label = `${o.side} ${formatCompactAmount(o.quantity)} · ${formatRate(o.limitPrice)}`;
            const labelW = label.length * 6.6 + 12;
            return (
              <g key={o.id} className={`order-line ${side}`}>
                <line x1={M.left} x2={M.left + plotW} y1={y(o.limitPrice)} y2={y(o.limitPrice)} />
                <rect x={M.left + 4} y={ly - LABEL_H / 2} width={labelW} height={LABEL_H} rx={4} className="order-pill" />
                <text x={M.left + 10} y={ly} dy="0.34em" className="order-text">{label}</text>
              </g>
            );
          })}

          {/* Orders further than 0.5% away, pinned to the edge they're beyond. */}
          {[
            { list: above, edge: M.top - 11, arrow: '▲' },
            { list: below, edge: HEIGHT - 2 - LABEL_H / 2, arrow: '▼' },
          ].map(({ list, edge, arrow }) => {
            let cursor = M.left + 2;
            return list.map((o) => {
              const side = o.side === 'Sell' ? 'sell' : 'buy';
              const away = Math.abs(distanceToFill(o.side, spot, o.limitPrice)) * 100;
              const label = `${arrow} ${o.side} ${formatCompactAmount(o.quantity)} · ${formatRate(o.limitPrice)} · ${away.toFixed(2)}%`;
              const w = label.length * 6.2 + 12;
              const x0 = cursor;
              cursor += w + 6;
              if (x0 + w > M.left + plotW) return null;
              return (
                <g key={o.id} className={`order-pin ${side}`}>
                  <rect x={x0} y={edge - LABEL_H / 2} width={w} height={LABEL_H} rx={4} className="order-pill" />
                  <text x={x0 + 6} y={edge} dy="0.34em" className="order-text">{label}</text>
                </g>
              );
            });
          })}

          {/* Spot tag. */}
          <g className="spot-tag" transform={`translate(${M.left + plotW + 4},${y(spot)})`}>
            <rect x={0} y={-10} width={M.right - 8} height={20} rx={4} />
            <text x={(M.right - 8) / 2} dy="0.34em" textAnchor="middle">{formatRate(spot)}</text>
          </g>

          {/* Crosshair. */}
          {hoverY !== null && hoverPrice !== null && (
            <g className="crosshair" pointerEvents="none">
              <line x1={M.left} x2={M.left + plotW} y1={hoverY} y2={hoverY} />
              <g transform={`translate(${M.left + plotW + 4},${hoverY})`}>
                <rect x={0} y={-10} width={M.right - 8} height={20} rx={4} />
                <text x={(M.right - 8) / 2} dy="0.34em" textAnchor="middle">{formatRate(hoverPrice)}</text>
              </g>
              <text x={M.left + plotW - 6} y={hoverY - 7} textAnchor="end" className="crosshair-hint">
                Click to set limit
              </text>
            </g>
          )}
        </svg>
      </div>
    </article>
  );
}
