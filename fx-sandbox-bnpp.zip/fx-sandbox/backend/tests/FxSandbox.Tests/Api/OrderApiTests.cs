using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using FxSandbox.Api.Contracts;
using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using FxSandbox.Tests.Support;
using Microsoft.AspNetCore.Mvc;

namespace FxSandbox.Tests.Api;

public sealed class OrderApiTests : IClassFixture<SandboxApiFactory>, IAsyncLifetime
{
    private readonly HttpClient _client;

    public OrderApiTests(SandboxApiFactory factory) => _client = factory.CreateClient();

    // Tests in a class share one host, so start each from a clean account.
    public async Task InitializeAsync() => (await _client.PostAsync("/api/reset", null)).EnsureSuccessStatusCode();

    public Task DisposeAsync() => Task.CompletedTask;

    [Fact]
    public async Task Health_reports_healthy()
    {
        var response = await _client.GetAsync("/health");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        using var body = JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        Assert.Equal("Healthy", body.RootElement.GetProperty("status").GetString());
    }

    [Fact]
    public async Task The_snapshot_starts_with_starting_capital_three_pairs_and_the_seed_source()
    {
        var snapshot = await Get<SandboxSnapshot>("/api/snapshot?history=true");

        Assert.Equal(10_000m, snapshot.Account.AccountValue);
        Assert.Equal(10_000m, snapshot.Account.StartingCapital);
        Assert.Equal(["USD/EUR", "USD/GBP", "USD/CHF"], snapshot.Rates.Select(r => r.Pair));
        Assert.All(snapshot.Rates, r => Assert.NotEmpty(r.History!));
        Assert.Equal(RateSeedSource.Configured, snapshot.Seed.Source);
        Assert.Contains("turned off", snapshot.Seed.Description, StringComparison.Ordinal);
    }

    [Fact]
    public async Task Rates_positions_and_account_endpoints_respond()
    {
        var rates = await Get<List<RateView>>("/api/rates");
        var positions = await Get<List<PositionView>>("/api/positions");
        var account = await Get<AccountResponse>("/api/account");

        Assert.Equal(0.88m, rates[0].Rate);
        Assert.Null(rates[0].History);
        Assert.Equal(3, positions.Count);
        Assert.Equal(["USD", "EUR", "GBP", "CHF"], account.Balances.Select(b => b.Currency));
    }

    [Fact]
    public async Task An_order_can_be_placed_listed_and_cancelled_over_http()
    {
        // Place a resting sell.
        var response = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR", side = "Sell", quantity = 1000, limitPrice = 0.885 });
        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var raw = await response.Content.ReadAsStringAsync();
        Assert.Contains("\"side\":\"Sell\"", raw, StringComparison.Ordinal); // enums travel as strings
        var placed = JsonSerializer.Deserialize<PlaceOrderResult>(raw, SandboxApiFactory.Json)!;
        Assert.Equal(OrderStatus.Open, placed.Order.Status);
        Assert.Null(placed.Fill);
        Assert.Equal($"/api/orders/{placed.Order.Id}", response.Headers.Location!.AbsolutePath);

        // It shows in the open book and reserves USD.
        var open = await Get<List<OrderView>>("/api/orders?status=Open");
        Assert.Contains(open, o => o.Id == placed.Order.Id);
        var account = await Get<AccountResponse>("/api/account");
        Assert.Equal(1_000m, account.Balances.Single(b => b.Currency == "USD").Reserved);

        // Cancel it: 204, funds released, status updated.
        var cancel = await _client.DeleteAsync($"/api/orders/{placed.Order.Id}");
        Assert.Equal(HttpStatusCode.NoContent, cancel.StatusCode);
        var order = await Get<OrderView>($"/api/orders/{placed.Order.Id}");
        Assert.Equal(OrderStatus.Cancelled, order.Status);
        account = await Get<AccountResponse>("/api/account");
        Assert.Equal(10_000m, account.Balances.Single(b => b.Currency == "USD").Available);

        // Cancelling again is a conflict.
        var again = await _client.DeleteAsync($"/api/orders/{placed.Order.Id}");
        Assert.Equal(HttpStatusCode.Conflict, again.StatusCode);
        var problem = await ReadProblem(again);
        Assert.Equal("Order can't be cancelled", problem.Title);
    }

    [Fact]
    public async Task A_marketable_order_returns_its_fill_and_creates_a_position()
    {
        var response = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR", side = "Sell", quantity = 1000, limitPrice = 0.87 });

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var placed = (await response.Content.ReadFromJsonAsync<PlaceOrderResult>(SandboxApiFactory.Json))!;
        Assert.Equal(OrderStatus.Filled, placed.Order.Status);
        Assert.NotNull(placed.Fill);
        Assert.Equal(0.88m, placed.Fill.Price);

        var eur = (await Get<List<PositionView>>("/api/positions")).Single(p => p.Pair == "USD/EUR");
        Assert.Equal(880m, eur.Amount);
        Assert.Equal(1_000m, eur.CostBasisUsd);
    }

    [Fact]
    public async Task Insufficient_funds_are_rejected_with_problem_details()
    {
        var response = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR", side = "Buy", quantity = 500, limitPrice = 0.898 });

        Assert.Equal(HttpStatusCode.UnprocessableEntity, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType!.MediaType);
        var problem = await ReadProblem(response);
        Assert.Equal("Insufficient funds", problem.Title);
        Assert.Equal("Not enough EUR: this order needs 449.00 and 0.00 is available.", problem.Detail);
        Assert.Equal("EUR", problem.Extensions["currency"]!.ToString());
    }

    [Fact]
    public async Task Invalid_fields_are_rejected_with_validation_problem_details()
    {
        var response = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/JPY", side = "Sell", quantity = 10.123, limitPrice = 0.88 });

        Assert.Equal(HttpStatusCode.BadRequest, response.StatusCode);
        Assert.Equal("application/problem+json", response.Content.Headers.ContentType!.MediaType);
        var problem = (await response.Content.ReadFromJsonAsync<ValidationProblemDetails>(SandboxApiFactory.Json))!;
        Assert.Contains("pair", problem.Errors.Keys);
        Assert.Contains("quantity", problem.Errors.Keys);
    }

    [Fact]
    public async Task Missing_fields_and_unknown_sides_are_rejected_before_reaching_the_engine()
    {
        var missing = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR" });
        var badSide = await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR", side = "Hold", quantity = 1, limitPrice = 0.88 });

        Assert.Equal(HttpStatusCode.BadRequest, missing.StatusCode);
        var problem = (await missing.Content.ReadFromJsonAsync<ValidationProblemDetails>(SandboxApiFactory.Json))!;
        Assert.Equal(["limitPrice", "quantity", "side"], problem.Errors.Keys.Order());
        Assert.Equal(HttpStatusCode.BadRequest, badSide.StatusCode);
    }

    [Fact]
    public async Task Unknown_orders_and_paths_return_404_problem_details()
    {
        var order = await _client.DeleteAsync($"/api/orders/{Guid.NewGuid()}");
        var path = await _client.GetAsync("/api/does-not-exist");

        Assert.Equal(HttpStatusCode.NotFound, order.StatusCode);
        Assert.Equal("Order not found", (await ReadProblem(order)).Title);
        Assert.Equal(HttpStatusCode.NotFound, path.StatusCode);
        Assert.Equal("application/problem+json", path.Content.Headers.ContentType!.MediaType);
    }

    [Fact]
    public async Task Reset_restores_the_starting_account()
    {
        await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/GBP", side = "Sell", quantity = 2500, limitPrice = 0.7 });
        await _client.PostAsJsonAsync("/api/orders", new { pair = "USD/CHF", side = "Sell", quantity = 100, limitPrice = 0.81 });

        var reset = await _client.PostAsync("/api/reset", null);

        Assert.Equal(HttpStatusCode.OK, reset.StatusCode);
        var snapshot = await Get<SandboxSnapshot>("/api/snapshot");
        Assert.Empty(snapshot.Orders);
        Assert.Equal(10_000m, snapshot.Account.UsdCash);
        Assert.All(snapshot.Positions, p => Assert.Equal(0m, p.Amount));
    }

    [Fact]
    public async Task Swagger_describes_the_api_with_string_enums()
    {
        var json = await _client.GetStringAsync("/swagger/v1/swagger.json");

        Assert.Contains("/api/orders/{id}", json, StringComparison.Ordinal);
        Assert.Contains("\"Sell\"", json, StringComparison.Ordinal);
    }

    private async Task<T> Get<T>(string url)
    {
        var response = await _client.GetAsync(url);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync<T>(SandboxApiFactory.Json))!;
    }

    private static async Task<ProblemDetails> ReadProblem(HttpResponseMessage response) =>
        (await response.Content.ReadFromJsonAsync<ProblemDetails>(SandboxApiFactory.Json))!;
}
