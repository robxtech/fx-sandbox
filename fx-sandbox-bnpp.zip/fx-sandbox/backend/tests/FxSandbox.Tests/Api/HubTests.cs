using System.Net.Http.Json;
using System.Text.Json.Serialization;
using FxSandbox.Core.Snapshots;
using FxSandbox.Tests.Support;
using Microsoft.AspNetCore.Http.Connections;
using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;

namespace FxSandbox.Tests.Api;

public sealed class HubTests : IClassFixture<SandboxApiFactory>
{
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(10);
    private readonly SandboxApiFactory _factory;

    public HubTests(SandboxApiFactory factory) => _factory = factory;

    [Fact]
    public async Task A_new_connection_gets_a_snapshot_with_history_then_updates_after_trader_actions()
    {
        var withHistory = new TaskCompletionSource<SandboxSnapshot>(TaskCreationOptions.RunContinuationsAsynchronously);
        var afterOrder = new TaskCompletionSource<SandboxSnapshot>(TaskCreationOptions.RunContinuationsAsynchronously);

        await using var connection = new HubConnectionBuilder()
            .WithUrl(new Uri(_factory.Server.BaseAddress, "hubs/sandbox"), options =>
            {
                options.HttpMessageHandlerFactory = _ => _factory.Server.CreateHandler();
                options.Transports = HttpTransportType.LongPolling;
            })
            .AddJsonProtocol(options => options.PayloadSerializerOptions.Converters.Add(new JsonStringEnumConverter()))
            .Build();

        connection.On<SandboxSnapshot>("Snapshot", snapshot =>
        {
            if (snapshot.Rates.All(r => r.History is not null))
            {
                withHistory.TrySetResult(snapshot);
            }

            if (snapshot.Orders.Count > 0)
            {
                afterOrder.TrySetResult(snapshot);
            }
        });

        await connection.StartAsync();
        var first = await withHistory.Task.WaitAsync(Timeout);
        Assert.Equal(3, first.Rates.Count);

        var client = _factory.CreateClient();
        await client.PostAsync("/api/reset", null);
        (await client.PostAsJsonAsync("/api/orders", new { pair = "USD/EUR", side = "Sell", quantity = 100, limitPrice = 0.885 }))
            .EnsureSuccessStatusCode();

        var pushed = await afterOrder.Task.WaitAsync(Timeout);
        Assert.Single(pushed.Orders);
    }
}
