using FxSandbox.Core;
using FxSandbox.Tests.Support;

namespace FxSandbox.Tests.Domain;

public sealed class MatchingTests
{
    private readonly TestEngine _t = new();

    [Fact]
    public void A_sell_rests_until_the_rate_rises_to_its_limit_then_fills_at_spot()
    {
        var order = _t.Place(OrderSide.Sell, 1_000m, 0.88200m).Order;

        _t.Tick(0.5);
        _t.Tick(0.0);
        Assert.Equal(OrderStatus.Open, _t.Engine.GetOrder(order.Id)!.Status);

        var fills = _t.RiseTo(0.88200m);

        var fill = Assert.Single(fills);
        Assert.Equal(order.Id, fill.OrderId);
        Assert.Equal(_t.Rate("USD/EUR"), fill.Price);
        Assert.True(fill.Price >= 0.88200m);
        Assert.Equal(Money.RoundAmount(1_000m * fill.Price), fill.QuoteAmount);
        Assert.Equal(OrderStatus.Filled, _t.Engine.GetOrder(order.Id)!.Status);
        Assert.Equal(0m, _t.Reserved("USD"));
    }

    [Fact]
    public void A_buy_rests_until_the_rate_falls_to_its_limit_then_fills_at_spot()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m); // 880 EUR
        var order = _t.Place(OrderSide.Buy, 500m, 0.87800m).Order;

        _t.Tick(1.0);
        Assert.Equal(OrderStatus.Open, _t.Engine.GetOrder(order.Id)!.Status);

        var fill = Assert.Single(_t.FallTo(0.87800m));

        Assert.Equal(order.Id, fill.OrderId);
        Assert.True(fill.Price <= 0.87800m);
        Assert.Equal(Money.RoundAmount(500m * fill.Price), fill.QuoteAmount);
        Assert.Equal(0m, _t.Reserved("EUR"));
    }

    [Fact]
    public void A_sell_does_not_fill_when_the_rate_falls()
    {
        var order = _t.Place(OrderSide.Sell, 1_000m, 0.88100m).Order;

        _t.FallTo(0.86000m);

        Assert.Equal(OrderStatus.Open, _t.Engine.GetOrder(order.Id)!.Status);
    }

    [Fact]
    public void Orders_at_the_same_level_fill_oldest_first()
    {
        var first = _t.Place(OrderSide.Sell, 100m, 0.88100m).Order;
        var second = _t.Place(OrderSide.Sell, 200m, 0.88100m).Order;
        var third = _t.Place(OrderSide.Sell, 300m, 0.88100m).Order;

        var fills = _t.RiseTo(0.88100m);

        Assert.Equal([first.Id, second.Id, third.Id], fills.Select(f => f.OrderId));
        Assert.True(fills[0].Sequence < fills[1].Sequence && fills[1].Sequence < fills[2].Sequence);
    }

    [Fact]
    public void Triggered_orders_fill_in_price_then_time_priority()
    {
        // All three trigger on the same big tick; the most aggressive limit goes first.
        var high = _t.Place(OrderSide.Sell, 100m, 0.88080m).Order;
        var low = _t.Place(OrderSide.Sell, 100m, 0.88010m).Order;
        var lowLater = _t.Place(OrderSide.Sell, 100m, 0.88010m).Order;

        var fills = _t.Tick(1.0).Fills; // 0.88 → 0.88088

        Assert.Equal([low.Id, lowLater.Id, high.Id], fills.Select(f => f.OrderId));
    }

    [Fact]
    public void Orders_only_react_to_their_own_pair()
    {
        var gbp = _t.Place(OrderSide.Sell, 100m, 0.75050m, "USD/GBP").Order;

        _t.Random.Enqueue(1.0, 0.5, 0.5); // EUR up, GBP and CHF flat
        _t.Time.Advance(TimeSpan.FromSeconds(1));
        _t.Engine.Tick();

        Assert.Equal(OrderStatus.Open, _t.Engine.GetOrder(gbp.Id)!.Status);
    }

    [Fact]
    public void History_is_capped_and_ends_with_the_current_rate()
    {
        var t = new TestEngine(s => s.HistoryLength = 5);
        for (var i = 0; i < 12; i++)
        {
            t.Tick(1.0);
        }

        var rate = t.Engine.GetRates(includeHistory: true).Single(r => r.Pair == "USD/EUR");
        Assert.Equal(5, rate.History!.Count);
        Assert.Equal(rate.Rate, rate.History[^1]);
        Assert.Null(t.Engine.GetRates()[0].History);
    }

    [Fact]
    public void Seeding_restarts_the_walk_from_new_rates()
    {
        _t.Tick(1.0);
        var rates = CurrencyPair.All.ToDictionary(p => p, _ => 0.5m);

        _t.Engine.Seed(new RateSeed(RateSeedSource.Live, rates, "test", new DateOnly(2026, 9, 25)));

        var snapshot = _t.Engine.GetSnapshot(includeHistory: true);
        Assert.Equal(RateSeedSource.Live, snapshot.Seed.Source);
        Assert.All(snapshot.Rates, r => Assert.Equal([0.5m], r.History!));
    }
}
