using FxSandbox.Core;
using FxSandbox.Tests.Support;

namespace FxSandbox.Tests.Domain;

public sealed class CancelAndResetTests
{
    private readonly TestEngine _t = new();

    [Fact]
    public void Cancelling_releases_the_reservation()
    {
        var order = _t.Place(OrderSide.Sell, 2_500m, 0.88500m).Order;
        Assert.Equal(7_500m, _t.Available("USD"));

        var cancelled = _t.Engine.CancelOrder(order.Id);

        Assert.Equal(OrderStatus.Cancelled, cancelled.Status);
        Assert.NotNull(cancelled.ClosedAt);
        Assert.Equal(10_000m, _t.Available("USD"));
        Assert.Equal(0m, _t.Reserved("USD"));
    }

    [Fact]
    public void Cancelling_a_buy_releases_the_quote_currency()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);
        var order = _t.Place(OrderSide.Buy, 500m, 0.87500m).Order;
        Assert.Equal(437.50m, _t.Reserved("EUR"));

        _t.Engine.CancelOrder(order.Id);

        Assert.Equal(880.00m, _t.Available("EUR"));
    }

    [Fact]
    public void A_cancelled_order_cannot_be_cancelled_again()
    {
        var order = _t.Place(OrderSide.Sell, 100m, 0.88500m).Order;
        _t.Engine.CancelOrder(order.Id);

        var ex = Assert.Throws<OrderNotCancellableException>(() => _t.Engine.CancelOrder(order.Id));

        Assert.Equal(OrderStatus.Cancelled, ex.Status);
        Assert.Equal(10_000m, _t.Available("USD")); // released once, not twice
    }

    [Fact]
    public void A_cancelled_order_never_fills()
    {
        var order = _t.Place(OrderSide.Sell, 100m, 0.88100m).Order;
        _t.Engine.CancelOrder(order.Id);

        Assert.Empty(_t.RiseTo(0.88300m));
    }

    [Fact]
    public void A_filled_order_cannot_be_cancelled()
    {
        var order = _t.Place(OrderSide.Sell, 100m, 0.87000m).Order;

        var ex = Assert.Throws<OrderNotCancellableException>(() => _t.Engine.CancelOrder(order.Id));
        Assert.Equal(OrderStatus.Filled, ex.Status);
    }

    [Fact]
    public void Cancelling_an_unknown_order_is_not_found()
    {
        Assert.Throws<OrderNotFoundException>(() => _t.Engine.CancelOrder(Guid.NewGuid()));
    }

    [Fact]
    public void Reset_restores_starting_capital_and_clears_orders_and_positions_but_keeps_the_market()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);
        _t.Place(OrderSide.Sell, 500m, 0.89000m);
        _t.Tick(1.0);
        var rateBefore = _t.Rate("USD/EUR");

        _t.Engine.Reset();

        var snapshot = _t.Engine.GetSnapshot();
        Assert.Empty(snapshot.Orders);
        Assert.Empty(snapshot.Fills);
        Assert.All(snapshot.Positions, p => Assert.Equal(0m, p.Amount));
        Assert.Equal([10_000m, 0m, 0m, 0m], snapshot.Balances.Select(b => b.Available));
        Assert.Equal(10_000m, snapshot.Account.AccountValue);
        Assert.Equal(0m, snapshot.Account.RealisedPnl);
        Assert.Equal(rateBefore, _t.Rate("USD/EUR"));
    }

    [Fact]
    public void Closed_orders_are_retained_up_to_the_configured_limit()
    {
        var t = new TestEngine(s => s.ClosedOrderRetention = 3);
        var ids = Enumerable.Range(0, 5).Select(_ => t.Place(OrderSide.Sell, 10m, 0.88500m).Order.Id).ToList();
        ids.ForEach(id => t.Engine.CancelOrder(id));

        var closed = t.Engine.GetOrders(OrderStatus.Cancelled);

        Assert.Equal(ids.AsEnumerable().Reverse().Take(3), closed.Select(o => o.Id));
        Assert.Null(t.Engine.GetOrder(ids[0]));
    }
}
