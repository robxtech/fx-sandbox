using FxSandbox.Core;
using FxSandbox.Tests.Support;

namespace FxSandbox.Tests.Domain;

public sealed class OrderPlacementTests
{
    private readonly TestEngine _t = new();

    [Fact]
    public void A_resting_sell_reserves_the_usd_amount()
    {
        var result = _t.Place(OrderSide.Sell, 1_000m, 0.88500m);

        Assert.Equal(OrderStatus.Open, result.Order.Status);
        Assert.Null(result.Fill);
        Assert.Equal("USD", result.Order.ReservedCurrency);
        Assert.Equal(1_000m, result.Order.ReservedAmount);
        Assert.Equal(1_000m, _t.Reserved("USD"));
        Assert.Equal(9_000m, _t.Available("USD"));
    }

    [Fact]
    public void A_resting_buy_reserves_quantity_times_limit_in_the_quote_currency()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m); // fills now: 880.00 EUR

        var result = _t.Place(OrderSide.Buy, 500m, 0.87123m);

        Assert.Equal("EUR", result.Order.ReservedCurrency);
        Assert.Equal(435.62m, result.Order.ReservedAmount); // 500 × 0.87123 = 435.615, rounded half away from zero
        Assert.Equal(435.62m, _t.Reserved("EUR"));
        Assert.Equal(880.00m - 435.62m, _t.Available("EUR"));
    }

    [Fact]
    public void A_buy_without_enough_quote_currency_is_rejected_with_a_clear_message()
    {
        var ex = Assert.Throws<InsufficientFundsException>(() => _t.Place(OrderSide.Buy, 500m, 0.89800m));

        Assert.Equal("Not enough EUR: this order needs 449.00 and 0.00 is available.", ex.Message);
        Assert.Equal("EUR", ex.Currency);
        Assert.Empty(_t.Engine.GetOrders());
    }

    [Fact]
    public void Reserved_usd_is_not_available_to_later_orders()
    {
        _t.Place(OrderSide.Sell, 6_000m, 0.89000m);

        var ex = Assert.Throws<InsufficientFundsException>(() => _t.Place(OrderSide.Sell, 5_000m, 0.89000m));

        Assert.Equal("Not enough USD: this order needs 5,000.00 and 4,000.00 is available.", ex.Message);
    }

    [Fact]
    public void Exactly_the_available_amount_is_accepted()
    {
        var result = _t.Place(OrderSide.Sell, 10_000m, 0.89000m);

        Assert.Equal(OrderStatus.Open, result.Order.Status);
        Assert.Equal(0m, _t.Available("USD"));
    }

    [Theory]
    [InlineData("USD/JPY", "pair")]
    [InlineData("", "pair")]
    [InlineData("EUR/USD", "pair")]
    public void Unknown_pairs_are_rejected(string pair, string field)
    {
        var ex = Assert.Throws<OrderValidationException>(() => _t.Place(OrderSide.Sell, 100m, 0.88m, pair));
        Assert.Contains(field, ex.Errors.Keys);
    }

    [Theory]
    [InlineData("usd/eur")]
    [InlineData("USDEUR")]
    [InlineData("USD-EUR")]
    public void Pair_symbols_are_parsed_leniently(string pair)
    {
        var result = _t.Place(OrderSide.Sell, 100m, 0.89m, pair);
        Assert.Equal("USD/EUR", result.Order.Pair);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-5)]
    [InlineData(10.001)]
    public void Invalid_quantities_are_rejected(double quantity)
    {
        var ex = Assert.Throws<OrderValidationException>(() => _t.Place(OrderSide.Sell, (decimal)quantity, 0.88m));
        Assert.Contains("quantity", ex.Errors.Keys);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(-0.88)]
    [InlineData(0.880001)]
    [InlineData(1.1)]   // more than 20% above spot
    [InlineData(0.6)]   // more than 20% below spot
    public void Invalid_limit_prices_are_rejected(double limit)
    {
        var ex = Assert.Throws<OrderValidationException>(() => _t.Place(OrderSide.Sell, 100m, (decimal)limit));
        Assert.Contains("limitPrice", ex.Errors.Keys);
    }

    [Fact]
    public void Every_invalid_field_is_reported_together()
    {
        var ex = Assert.Throws<OrderValidationException>(() => _t.Place(OrderSide.Sell, 0m, 0m, "XXX"));
        Assert.Equal(["limitPrice", "pair", "quantity"], ex.Errors.Keys.Order());
    }

    [Fact]
    public void A_marketable_sell_fills_immediately_at_the_spot_rate()
    {
        // Selling at 0.87 or higher when spot is 0.88: marketable, and it fills at the better spot rate.
        var result = _t.Place(OrderSide.Sell, 1_000m, 0.87000m);

        Assert.Equal(OrderStatus.Filled, result.Order.Status);
        Assert.NotNull(result.Fill);
        Assert.Equal(0.88000m, result.Fill.Price);
        Assert.Equal(880.00m, result.Fill.QuoteAmount);
        Assert.Equal(9_000m, _t.Available("USD"));
        Assert.Equal(0m, _t.Reserved("USD"));
        Assert.Equal(880.00m, _t.Available("EUR"));
    }

    [Fact]
    public void A_marketable_buy_fills_immediately_at_the_spot_rate()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);

        // Buying USD at 0.89 or lower when spot is 0.88: marketable, pays the better spot rate.
        var result = _t.Place(OrderSide.Buy, 500m, 0.89000m);

        Assert.Equal(OrderStatus.Filled, result.Order.Status);
        Assert.Equal(0.88000m, result.Fill!.Price);
        Assert.Equal(440.00m, result.Fill.QuoteAmount);
        Assert.Equal(440.00m, _t.Available("EUR"));
        Assert.Equal(0m, _t.Reserved("EUR"));
        Assert.Equal(9_500m, _t.Available("USD"));
    }
}
