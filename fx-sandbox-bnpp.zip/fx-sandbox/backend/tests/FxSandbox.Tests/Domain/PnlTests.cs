using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using FxSandbox.Tests.Support;

namespace FxSandbox.Tests.Domain;

public sealed class PnlTests
{
    private readonly TestEngine _t = new();

    private PositionView Eur() => _t.Engine.GetPositions().Single(p => p.Pair == "USD/EUR");

    [Fact]
    public void A_sell_fill_creates_a_position_with_a_usd_cost_basis()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);

        var position = Eur();
        Assert.Equal("EUR", position.Currency);
        Assert.Equal(880.00m, position.Amount);
        Assert.Equal(1_000m, position.CostBasisUsd);
        Assert.Equal(0.88000m, position.AverageRate);
        Assert.Equal(0m, position.UnrealisedPnl);
    }

    [Fact]
    public void Unrealised_pnl_moves_with_the_rate()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m); // hold 880 EUR, cost 1,000 USD

        _t.Tick(1.0); // USD strengthens: EUR is worth fewer dollars
        var afterRise = Eur();
        Assert.Equal(Money.RoundAmount((880m / afterRise.CurrentRate) - 1_000m), afterRise.UnrealisedPnl);
        Assert.True(afterRise.UnrealisedPnl < 0);

        _t.FallTo(0.87500m); // USD weakens: EUR is worth more dollars
        var afterFall = Eur();
        Assert.Equal(Money.RoundAmount((880m / afterFall.CurrentRate) - 1_000m), afterFall.UnrealisedPnl);
        Assert.True(afterFall.UnrealisedPnl > 0);

        var account = _t.Engine.GetAccount();
        Assert.Equal(afterFall.UnrealisedPnl, account.UnrealisedPnl);
        Assert.Equal(0m, account.RealisedPnl);
    }

    [Fact]
    public void Buying_usd_back_reduces_the_cost_basis_pro_rata_and_books_realised_pnl()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m); // 880.00 EUR for 1,000 USD
        _t.FallTo(0.87000m);
        var spot = _t.Rate("USD/EUR");

        var fill = _t.Place(OrderSide.Buy, 500m, spot).Fill!;

        var paid = Money.RoundAmount(500m * spot);
        var costReleased = Money.RoundAmount(1_000m * paid / 880m);
        Assert.Equal(paid, fill.QuoteAmount);
        Assert.Equal(500m - costReleased, fill.RealisedPnl);
        Assert.True(fill.RealisedPnl > 0, "Buying USD back cheaper than it was sold books a profit.");

        var position = Eur();
        Assert.Equal(880m - paid, position.Amount);
        Assert.Equal(1_000m - costReleased, position.CostBasisUsd);
        Assert.Equal(fill.RealisedPnl, position.RealisedPnl);
        Assert.Equal(fill.RealisedPnl, _t.Engine.GetAccount().RealisedPnl);
    }

    [Fact]
    public void Buying_back_at_a_worse_rate_books_a_loss()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);
        _t.RiseTo(0.88500m);
        _t.FallTo(0.88400m); // settle somewhere above the entry rate
        var spot = _t.Rate("USD/EUR");

        // Spend all the EUR buying USD back: fewer dollars come back than were sold.
        var usd = Math.Floor(880m / spot * 100m) / 100m;
        var fill = _t.Place(OrderSide.Buy, usd, spot).Fill!;

        Assert.True(fill.RealisedPnl < 0);
    }

    [Fact]
    public void Closing_the_whole_position_leaves_no_cost_basis()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);
        _t.Place(OrderSide.Buy, 1_000m, 0.88000m);

        var position = Eur();
        Assert.Equal(0m, position.Amount);
        Assert.Equal(0m, position.CostBasisUsd);
        Assert.Null(position.AverageRate);
        Assert.Equal(0m, position.RealisedPnl);
        Assert.Equal(10_000m, _t.Engine.GetAccount().AccountValue);
    }

    [Fact]
    public void Account_value_is_usd_cash_plus_positions_marked_to_usd()
    {
        _t.Place(OrderSide.Sell, 1_000m, 0.88000m);
        _t.Place(OrderSide.Sell, 2_000m, 0.75000m, "USD/GBP");
        _t.Tick(0.9);

        var account = _t.Engine.GetAccount();
        var positions = _t.Engine.GetPositions();

        Assert.Equal(7_000m, account.UsdCash);
        var exact = 7_000m + positions.Sum(p => p.Amount / p.CurrentRate);
        Assert.Equal(Money.RoundAmount(exact), account.AccountValue);
    }

    [Theory]
    [InlineData(1)]
    [InlineData(99)]
    [InlineData(2026)]
    public void Equity_always_equals_starting_capital_plus_unrealised_plus_realised(int seed)
    {
        var random = new Random(seed);
        var t = new TestEngine();
        var pairs = CurrencyPair.All.Select(p => p.Symbol).ToArray();

        for (var step = 0; step < 2_000; step++)
        {
            if (random.NextDouble() < 0.3)
            {
                var pair = pairs[random.Next(pairs.Length)];
                var side = random.Next(2) == 0 ? OrderSide.Buy : OrderSide.Sell;
                var spot = t.Rate(pair);
                var limit = Money.RoundRate(spot * (1m + ((decimal)random.NextDouble() - 0.5m) * 0.004m));
                var quantity = Math.Round((decimal)random.NextDouble() * 1_500m, 2) + 0.01m;
                try
                {
                    t.Place(side, quantity, limit, pair);
                }
                catch (InsufficientFundsException)
                {
                    // Expected when the wallet runs short; the invariant must still hold.
                }
            }

            if (random.NextDouble() < 0.05)
            {
                var open = t.Engine.GetOrders(OrderStatus.Open);
                if (open.Count > 0)
                {
                    t.Engine.CancelOrder(open[random.Next(open.Count)].Id);
                }
            }

            t.Tick(random.NextDouble());

            var (value, unrealised, realised) = t.Engine.ValueAccountExactly();
            Assert.InRange(value - (t.Settings.StartingCapital + unrealised + realised), -0.0000001m, 0.0000001m);
            Assert.All(t.Engine.GetBalances(), b => Assert.True(b.Available >= 0, $"{b.Currency} went negative."));
        }

        Assert.NotEmpty(t.Engine.GetSnapshot().Fills);
    }
}
