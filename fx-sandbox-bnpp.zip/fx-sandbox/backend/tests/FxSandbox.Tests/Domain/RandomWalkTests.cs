using FxSandbox.Core;

namespace FxSandbox.Tests.Domain;

public sealed class RandomWalkTests
{
    [Theory]
    [InlineData(0.0, -0.001)]
    [InlineData(0.5, 0.0)]
    [InlineData(1.0, 0.001)]
    [InlineData(0.75, 0.0005)]
    public void Delta_maps_the_sample_onto_the_step_range(double sample, double expected)
    {
        Assert.Equal((decimal)expected, RandomWalk.Delta(sample));
    }

    [Fact]
    public void Delta_stays_within_bounds_for_any_sample()
    {
        var random = new Random(1);
        for (var i = 0; i < 10_000; i++)
        {
            var delta = RandomWalk.Delta(random.NextDouble());
            Assert.InRange(delta, -0.001m, 0.001m);
        }
    }

    [Theory]
    [InlineData(-0.01)]
    [InlineData(1.01)]
    [InlineData(double.NaN)]
    public void Delta_rejects_samples_outside_zero_to_one(double sample)
    {
        Assert.Throws<ArgumentOutOfRangeException>(() => RandomWalk.Delta(sample));
    }

    [Fact]
    public void Next_applies_the_formula_and_rounds_to_five_decimal_places()
    {
        // 0.88 × (1 + 0.0005) = 0.88044 exactly.
        Assert.Equal(0.88044m, RandomWalk.Next(0.88m, 0.75));
        // 0.87891 × 1.001 = 0.87978891, which rounds towards the previous rate: 0.87978.
        Assert.Equal(0.87978m, RandomWalk.Next(0.87891m, 1.0));
    }

    [Theory]
    [InlineData(42)]
    [InlineData(7)]
    [InlineData(2026)]
    public void Ten_thousand_steps_each_stay_within_a_tenth_of_a_percent(int seed)
    {
        var random = new Random(seed);
        var rate = 0.87891m;
        for (var i = 0; i < 10_000; i++)
        {
            var next = RandomWalk.Next(rate, random.NextDouble());

            Assert.InRange(Math.Abs((next / rate) - 1m), 0m, 0.001m);
            Assert.Equal(Math.Round(next, 5), next);
            rate = next;
        }
    }

    [Theory]
    [InlineData(0.0)]
    [InlineData(1.0)]
    public void Extreme_samples_never_break_the_bound_after_rounding(double sample)
    {
        var rate = 0.87891m;
        for (var i = 0; i < 10_000; i++)
        {
            var next = RandomWalk.Next(rate, sample);
            Assert.InRange(Math.Abs((next / rate) - 1m), 0m, 0.001m);
            Assert.True(next > 0);
            rate = next;
        }
    }
}
