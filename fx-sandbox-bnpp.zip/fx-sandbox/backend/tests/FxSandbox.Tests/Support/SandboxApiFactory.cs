using System.Text.Json;
using System.Text.Json.Serialization;
using FxSandbox.Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace FxSandbox.Tests.Support;

/// <summary>
/// Hosts the real API in memory. Live rates are off (no network) and the random walk is flat
/// (every sample is 0.5), so rates stay at the configured seed and tests are deterministic.
/// </summary>
public sealed class SandboxApiFactory : WebApplicationFactory<Program>
{
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() },
    };

    public ControlledRandom Random { get; } = new();

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Testing");
        builder.UseSetting("LiveRates:Enabled", "false");
        builder.UseSetting("Sandbox:FallbackRates:EUR", "0.88");
        builder.UseSetting("Sandbox:FallbackRates:GBP", "0.75");
        builder.UseSetting("Sandbox:FallbackRates:CHF", "0.8");
        builder.ConfigureTestServices(services =>
        {
            services.RemoveAll<IRandomSource>();
            services.AddSingleton<IRandomSource>(Random);
        });
    }
}
