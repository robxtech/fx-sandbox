using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.Extensions.Time.Testing;

namespace FxSandbox.Tests.Support;

/// <summary>An engine with round starting rates, a scripted random source and a fake clock.</summary>
public sealed class TestEngine
{
    public const decimal EurSeed = 0.88000m;

    public TestEngine(Action<SandboxSettings>? configure = null)
    {
        Settings = new SandboxSettings
        {
            FallbackRates = new(StringComparer.OrdinalIgnoreCase)
            {
                [Currencies.Eur] = EurSeed,
                [Currencies.Gbp] = 0.75000m,
                [Currencies.Chf] = 0.80000m,
            },
        };
        configure?.Invoke(Settings);
        Engine = new SandboxEngine(Settings, Random, Time);
    }

    public SandboxSettings Settings { get; }

    public ControlledRandom Random { get; } = new();

    public FakeTimeProvider Time { get; } = new(new DateTimeOffset(2026, 9, 28, 9, 0, 0, TimeSpan.Zero));

    public SandboxEngine Engine { get; }

    public decimal Rate(string pair) => Engine.GetRates().Single(r => r.Pair == pair).Rate;

    public decimal Available(string currency) => Engine.GetBalances().Single(b => b.Currency == currency).Available;

    public decimal Reserved(string currency) => Engine.GetBalances().Single(b => b.Currency == currency).Reserved;

    public PlaceOrderResult Place(OrderSide side, decimal quantity, decimal limit, string pair = "USD/EUR") =>
        Engine.PlaceOrder(new OrderRequest(pair, side, quantity, limit));

    /// <summary>Ticks once with every pair moving by the given sample.</summary>
    public TickResult Tick(double sample = 0.5)
    {
        Random.Sample = sample;
        Time.Advance(TimeSpan.FromSeconds(1));
        return Engine.Tick();
    }

    /// <summary>Ticks every pair upwards (+0.1%) until USD/EUR reaches <paramref name="target"/> or higher.</summary>
    public List<FillView> RiseTo(decimal target) => MoveUntil(1.0, r => r >= target);

    /// <summary>Ticks every pair downwards (-0.1%) until USD/EUR reaches <paramref name="target"/> or lower.</summary>
    public List<FillView> FallTo(decimal target) => MoveUntil(0.0, r => r <= target);

    private List<FillView> MoveUntil(double sample, Func<decimal, bool> reached)
    {
        var fills = new List<FillView>();
        for (var i = 0; i < 10_000 && !reached(Rate("USD/EUR")); i++)
        {
            fills.AddRange(Tick(sample).Fills);
        }

        Assert.True(reached(Rate("USD/EUR")), "The rate never reached the target.");
        return fills;
    }
}
