using FxSandbox.Core;

namespace FxSandbox.Tests.Support;

/// <summary>
/// A scripted random source. Returns queued samples first, then <see cref="Sample"/>.
/// 0.5 means "no move", 1 means "+0.1%" and 0 means "-0.1%".
/// </summary>
public sealed class ControlledRandom : IRandomSource
{
    private readonly Queue<double> _script = new();

    public double Sample { get; set; } = 0.5;

    public void Enqueue(params double[] samples)
    {
        foreach (var s in samples)
        {
            _script.Enqueue(s);
        }
    }

    public double NextDouble() => _script.Count > 0 ? _script.Dequeue() : Sample;
}
