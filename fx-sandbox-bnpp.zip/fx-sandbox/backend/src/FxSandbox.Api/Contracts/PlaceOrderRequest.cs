using System.ComponentModel.DataAnnotations;
using FxSandbox.Core;

namespace FxSandbox.Api.Contracts;

/// <summary>A request to place a limit order.</summary>
public sealed class PlaceOrderRequest
{
    /// <summary>The pair symbol: USD/EUR, USD/GBP or USD/CHF.</summary>
    /// <example>USD/EUR</example>
    [Required]
    public string? Pair { get; init; }

    /// <summary>
    /// Sell: sell USD and receive the quote currency; fills when the rate rises to the limit or higher.
    /// Buy: buy USD back, paying in the quote currency; fills when the rate falls to the limit or lower.
    /// </summary>
    /// <example>Sell</example>
    [Required]
    public OrderSide? Side { get; init; }

    /// <summary>The USD amount, up to 2 decimal places.</summary>
    /// <example>1000</example>
    [Required]
    public decimal? Quantity { get; init; }

    /// <summary>The limit rate in quote units per 1 USD, up to 5 decimal places.</summary>
    /// <example>0.88</example>
    [Required]
    public decimal? LimitPrice { get; init; }

    /// <summary>Converts the validated request into the domain request.</summary>
    /// <returns>The domain request.</returns>
    public OrderRequest ToDomain() => new(Pair!, Side!.Value, Quantity!.Value, LimitPrice!.Value);
}
