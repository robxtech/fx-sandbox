using FxSandbox.Core.Snapshots;

namespace FxSandbox.Api.Contracts;

/// <summary>Account totals in USD, with wallet balances per currency.</summary>
/// <param name="StartingCapital">The capital the account started with.</param>
/// <param name="UsdCash">USD held, including any reserved for orders.</param>
/// <param name="AccountValue">USD cash plus every position marked to USD.</param>
/// <param name="UnrealisedPnl">The sum of unrealised P&amp;L across positions.</param>
/// <param name="RealisedPnl">The sum of realised P&amp;L across positions.</param>
/// <param name="Balances">Balance, reserved and available amounts per currency.</param>
public sealed record AccountResponse(
    decimal StartingCapital,
    decimal UsdCash,
    decimal AccountValue,
    decimal UnrealisedPnl,
    decimal RealisedPnl,
    IReadOnlyList<BalanceView> Balances)
{
    /// <summary>Builds the response from a snapshot, so totals and balances come from the same moment.</summary>
    /// <param name="snapshot">The snapshot to read.</param>
    /// <returns>The response.</returns>
    public static AccountResponse From(SandboxSnapshot snapshot)
    {
        ArgumentNullException.ThrowIfNull(snapshot);
        var a = snapshot.Account;
        return new AccountResponse(a.StartingCapital, a.UsdCash, a.AccountValue, a.UnrealisedPnl, a.RealisedPnl, snapshot.Balances);
    }
}
