using FxSandbox.Core;
using Microsoft.Extensions.Options;

namespace FxSandbox.Api.Infrastructure;

/// <summary>Advances the simulation on a fixed interval and broadcasts a snapshot after each tick.</summary>
internal sealed partial class TickerService : BackgroundService
{
    private readonly SandboxEngine _engine;
    private readonly SnapshotBroadcaster _broadcaster;
    private readonly TimeProvider _time;
    private readonly TimeSpan _interval;
    private readonly ILogger<TickerService> _logger;

    public TickerService(
        SandboxEngine engine,
        SnapshotBroadcaster broadcaster,
        TimeProvider time,
        IOptions<TickerOptions> options,
        ILogger<TickerService> logger)
    {
        _engine = engine;
        _broadcaster = broadcaster;
        _time = time;
        _interval = options.Value.Interval;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        using var timer = new PeriodicTimer(_interval, _time);
        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            try
            {
                var result = _engine.Tick();
                foreach (var fill in result.Fills)
                {
                    LogFill(fill.Side, fill.Quantity, fill.Pair, fill.Price, fill.OrderId);
                }

                await _broadcaster.PublishAsync();
            }
#pragma warning disable CA1031 // One bad tick must not stop the simulation; the failure is logged.
            catch (Exception ex)
#pragma warning restore CA1031
            {
                LogTickFailed(ex);
            }
        }
    }

    [LoggerMessage(Level = LogLevel.Information, Message = "Filled {Side} {Quantity} USD on {Pair} at {Price} (order {OrderId})")]
    private partial void LogFill(OrderSide side, decimal quantity, string pair, decimal price, Guid orderId);

    [LoggerMessage(Level = LogLevel.Error, Message = "A simulation tick failed")]
    private partial void LogTickFailed(Exception exception);
}
