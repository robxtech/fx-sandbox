using System.Net.Http.Json;
using FxSandbox.Core;

namespace FxSandbox.Api.Infrastructure;

/// <summary>Fetches live seed rates.</summary>
public interface ILiveRateProvider
{
    /// <summary>Fetches the latest rates for every simulated pair.</summary>
    /// <param name="cancellationToken">Cancels the request.</param>
    /// <returns>A live seed.</returns>
    Task<RateSeed> FetchAsync(CancellationToken cancellationToken);
}

/// <summary>Reads ECB reference rates from the Frankfurter API (https://frankfurter.dev).</summary>
internal sealed class FrankfurterRateProvider : ILiveRateProvider
{
    private readonly HttpClient _http;
    private readonly Uri _url;

    public FrankfurterRateProvider(HttpClient http, Microsoft.Extensions.Options.IOptions<LiveRatesOptions> options)
    {
        _http = http;
        _url = new Uri(options.Value.Url);
    }

    public async Task<RateSeed> FetchAsync(CancellationToken cancellationToken)
    {
        var body = await _http.GetFromJsonAsync<FrankfurterResponse>(_url, cancellationToken)
            ?? throw new InvalidDataException("The rates service returned an empty response.");

        if (!string.Equals(body.Base, Currencies.Usd, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidDataException($"Expected rates with base USD but got {body.Base}.");
        }

        var rates = new Dictionary<CurrencyPair, decimal>();
        foreach (var pair in CurrencyPair.All)
        {
            if (body.Rates is null || !body.Rates.TryGetValue(pair.Quote, out var rate) || rate <= 0)
            {
                throw new InvalidDataException($"The rates service did not return a rate for {pair.Quote}.");
            }

            rates[pair] = rate;
        }

        return new RateSeed(RateSeedSource.Live, rates, "ECB reference rates via Frankfurter", body.Date);
    }

    private sealed record FrankfurterResponse(string? Base, DateOnly? Date, Dictionary<string, decimal>? Rates);
}
