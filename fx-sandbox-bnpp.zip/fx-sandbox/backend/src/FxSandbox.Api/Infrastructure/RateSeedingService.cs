using System.Text.Json;
using FxSandbox.Core;
using Microsoft.Extensions.Options;

namespace FxSandbox.Api.Infrastructure;

/// <summary>
/// Seeds the random walk at start-up with live ECB rates, falling back to configured rates if the call
/// fails or takes longer than the timeout. Runs before the ticker and before the server accepts requests.
/// </summary>
internal sealed partial class RateSeedingService : IHostedService
{
    private readonly SandboxEngine _engine;
    private readonly ILiveRateProvider _provider;
    private readonly SandboxSettings _settings;
    private readonly LiveRatesOptions _options;
    private readonly ILogger<RateSeedingService> _logger;

    public RateSeedingService(
        SandboxEngine engine,
        ILiveRateProvider provider,
        IOptions<SandboxSettings> settings,
        IOptions<LiveRatesOptions> options,
        ILogger<RateSeedingService> logger)
    {
        _engine = engine;
        _provider = provider;
        _settings = settings.Value;
        _options = options.Value;
        _logger = logger;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        var seed = await ChooseSeedAsync(cancellationToken);
        _engine.Seed(seed);
        LogSeeded(seed.Description, string.Join(", ", seed.Rates.Select(r => $"{r.Key} {r.Value}")));
    }

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    private async Task<RateSeed> ChooseSeedAsync(CancellationToken cancellationToken)
    {
        if (!_options.Enabled)
        {
            return RateSeed.FromSettings(_settings, "live rates are turned off");
        }

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(_options.TimeoutSeconds));
        try
        {
            return await _provider.FetchAsync(timeout.Token);
        }
        catch (Exception ex) when (!cancellationToken.IsCancellationRequested &&
            ex is HttpRequestException or OperationCanceledException or InvalidDataException or JsonException)
        {
            LogLiveRatesUnavailable(ex.Message);
            return RateSeed.FromSettings(_settings, "live rates were unavailable");
        }
    }

    [LoggerMessage(Level = LogLevel.Information, Message = "Seeded rates from {Source}: {Rates}")]
    private partial void LogSeeded(string source, string rates);

    [LoggerMessage(Level = LogLevel.Warning, Message = "Live rates unavailable, using configured rates instead: {Reason}")]
    private partial void LogLiveRatesUnavailable(string reason);
}
