using FxSandbox.Api.Hubs;
using FxSandbox.Core;
using Microsoft.AspNetCore.SignalR;

namespace FxSandbox.Api.Infrastructure;

/// <summary>Pushes the current snapshot to every connected client.</summary>
public sealed class SnapshotBroadcaster
{
    private readonly SandboxEngine _engine;
    private readonly IHubContext<SandboxHub, ISandboxClient> _hub;

    /// <summary>Creates the broadcaster.</summary>
    /// <param name="engine">The trading engine.</param>
    /// <param name="hub">The hub context used to reach clients.</param>
    public SnapshotBroadcaster(SandboxEngine engine, IHubContext<SandboxHub, ISandboxClient> hub)
    {
        _engine = engine;
        _hub = hub;
    }

    /// <summary>Sends a snapshot (without rate history) to every client.</summary>
    /// <returns>A task that completes when the message is queued.</returns>
    public Task PublishAsync() => _hub.Clients.All.Snapshot(_engine.GetSnapshot(includeHistory: false));
}
