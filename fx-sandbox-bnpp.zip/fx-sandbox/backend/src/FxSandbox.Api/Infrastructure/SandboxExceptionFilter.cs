using FxSandbox.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace FxSandbox.Api.Infrastructure;

/// <summary>
/// Turns the engine's expected rejections into RFC 7807 ProblemDetails responses.
/// These are trader errors rather than server faults, so they're handled here and never logged as errors.
/// </summary>
internal sealed class SandboxExceptionFilter : IExceptionFilter
{
    private readonly ProblemDetailsFactory _problems;

    public SandboxExceptionFilter(ProblemDetailsFactory problems) => _problems = problems;

    public void OnException(ExceptionContext context)
    {
        if (context.Exception is not SandboxException exception)
        {
            return;
        }

        var http = context.HttpContext;
        ProblemDetails problem;
        switch (exception)
        {
            case OrderValidationException validation:
                var modelState = new ModelStateDictionary();
                foreach (var (field, messages) in validation.Errors)
                {
                    foreach (var message in messages)
                    {
                        modelState.AddModelError(field, message);
                    }
                }

                problem = _problems.CreateValidationProblemDetails(
                    http, modelState, StatusCodes.Status400BadRequest, "The order was rejected.", detail: validation.Message);
                break;

            case InsufficientFundsException funds:
                problem = _problems.CreateProblemDetails(
                    http, StatusCodes.Status422UnprocessableEntity, "Insufficient funds", detail: funds.Message);
                problem.Extensions["currency"] = funds.Currency;
                problem.Extensions["required"] = funds.Required;
                problem.Extensions["available"] = funds.Available;
                break;

            case OrderNotFoundException notFound:
                problem = _problems.CreateProblemDetails(
                    http, StatusCodes.Status404NotFound, "Order not found", detail: notFound.Message);
                break;

            case OrderNotCancellableException conflict:
                problem = _problems.CreateProblemDetails(
                    http, StatusCodes.Status409Conflict, "Order can't be cancelled", detail: conflict.Message);
                problem.Extensions["orderStatus"] = conflict.Status.ToString();
                break;

            default:
                problem = _problems.CreateProblemDetails(
                    http, StatusCodes.Status400BadRequest, "Request rejected", detail: exception.Message);
                break;
        }

        context.Result = new ObjectResult(problem)
        {
            StatusCode = problem.Status,
            ContentTypes = { "application/problem+json" },
        };
        context.ExceptionHandled = true;
    }
}
