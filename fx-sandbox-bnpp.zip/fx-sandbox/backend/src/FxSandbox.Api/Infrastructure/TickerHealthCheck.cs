using System.Globalization;
using FxSandbox.Core;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;

namespace FxSandbox.Api.Infrastructure;

/// <summary>Reports unhealthy if the simulation has stopped ticking.</summary>
internal sealed class TickerHealthCheck : IHealthCheck
{
    private const int MissedTicksBeforeUnhealthy = 5;

    private readonly SandboxEngine _engine;
    private readonly TimeProvider _time;
    private readonly TimeSpan _interval;

    public TickerHealthCheck(SandboxEngine engine, TimeProvider time, IOptions<TickerOptions> options)
    {
        _engine = engine;
        _time = time;
        _interval = options.Value.Interval;
    }

    public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
    {
        var lastTick = _engine.LastTickAt;
        if (lastTick is null)
        {
            return Task.FromResult(HealthCheckResult.Healthy("Starting; waiting for the first tick."));
        }

        var age = _time.GetUtcNow() - lastTick.Value;
        var data = new Dictionary<string, object>
        {
            ["lastTickAt"] = lastTick.Value.ToString("O", CultureInfo.InvariantCulture),
            ["tickIntervalMs"] = _interval.TotalMilliseconds,
        };

        var result = age > _interval * MissedTicksBeforeUnhealthy
            ? HealthCheckResult.Unhealthy($"No tick for {age.TotalSeconds:F0} seconds.", data: data)
            : HealthCheckResult.Healthy("Ticking.", data);
        return Task.FromResult(result);
    }
}
