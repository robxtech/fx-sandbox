using System.ComponentModel.DataAnnotations;

namespace FxSandbox.Api.Infrastructure;

/// <summary>How often the simulation ticks. Bound from the "Ticker" section.</summary>
public sealed class TickerOptions
{
    /// <summary>The configuration section name.</summary>
    public const string SectionName = "Ticker";

    /// <summary>Milliseconds between ticks.</summary>
    [Range(50, 60_000)]
    public int IntervalMs { get; set; } = 1000;

    /// <summary>The tick interval as a <see cref="TimeSpan"/>.</summary>
    public TimeSpan Interval => TimeSpan.FromMilliseconds(IntervalMs);
}

/// <summary>Where to fetch live seed rates from. Bound from the "LiveRates" section.</summary>
public sealed class LiveRatesOptions
{
    /// <summary>The configuration section name.</summary>
    public const string SectionName = "LiveRates";

    /// <summary>Whether to try live rates at start-up. When off, the configured fallback rates are used.</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>A Frankfurter "latest" URL with base USD.</summary>
    [Required]
    [Url]
    public string Url { get; set; } = "https://api.frankfurter.dev/v1/latest?base=USD&symbols=EUR,GBP,CHF";

    /// <summary>How long to wait before falling back to configured rates.</summary>
    [Range(1, 60)]
    public int TimeoutSeconds { get; set; } = 4;
}
