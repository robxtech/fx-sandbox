using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.AspNetCore.SignalR;

namespace FxSandbox.Api.Hubs;

/// <summary>Methods the server calls on connected clients.</summary>
public interface ISandboxClient
{
    /// <summary>Receives a full snapshot. Sent every tick, after every trader action, and on connect (with rate history).</summary>
    /// <param name="snapshot">The snapshot.</param>
    /// <returns>A task that completes when the message is queued.</returns>
    Task Snapshot(SandboxSnapshot snapshot);
}

/// <summary>
/// Pushes sandbox state to clients. The hub is one-way: trader actions go through the REST API,
/// so validation and error handling live in one place.
/// </summary>
public sealed class SandboxHub : Hub<ISandboxClient>
{
    /// <summary>The path the hub is mapped to.</summary>
    public const string Path = "/hubs/sandbox";

    private readonly SandboxEngine _engine;

    /// <summary>Creates the hub.</summary>
    /// <param name="engine">The trading engine.</param>
    public SandboxHub(SandboxEngine engine) => _engine = engine;

    /// <summary>Sends the new client a snapshot that includes rate history, so its charts start full.</summary>
    /// <returns>A task that completes when the snapshot is queued.</returns>
    public override async Task OnConnectedAsync()
    {
        await Clients.Caller.Snapshot(_engine.GetSnapshot(includeHistory: true));
        await base.OnConnectedAsync();
    }
}
