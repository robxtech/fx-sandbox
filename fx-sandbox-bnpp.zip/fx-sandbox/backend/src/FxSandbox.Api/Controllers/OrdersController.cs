using FxSandbox.Api.Contracts;
using FxSandbox.Api.Infrastructure;
using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.AspNetCore.Mvc;

namespace FxSandbox.Api.Controllers;

/// <summary>The order book: place, list and cancel limit orders.</summary>
[ApiController]
[Route("api/orders")]
[Produces("application/json")]
public sealed class OrdersController : ControllerBase
{
    private readonly SandboxEngine _engine;
    private readonly SnapshotBroadcaster _broadcaster;

    /// <summary>Creates the controller.</summary>
    /// <param name="engine">The trading engine.</param>
    /// <param name="broadcaster">Pushes state changes to connected clients.</param>
    public OrdersController(SandboxEngine engine, SnapshotBroadcaster broadcaster)
    {
        _engine = engine;
        _broadcaster = broadcaster;
    }

    /// <summary>Lists orders: open ones oldest first, then filled and cancelled ones newest first.</summary>
    /// <param name="status">Only return orders with this status: Open, Filled or Cancelled.</param>
    /// <returns>The orders.</returns>
    [HttpGet]
    [ProducesResponseType<IReadOnlyList<OrderView>>(StatusCodes.Status200OK)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    public IReadOnlyList<OrderView> List([FromQuery] OrderStatus? status = null) => _engine.GetOrders(status);

    /// <summary>Gets one order.</summary>
    /// <param name="id">The order id.</param>
    /// <returns>The order.</returns>
    [HttpGet("{id:guid}")]
    [ProducesResponseType<OrderView>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public ActionResult<OrderView> Get(Guid id) =>
        _engine.GetOrder(id) ?? throw new OrderNotFoundException(id);

    /// <summary>
    /// Places a limit order and reserves the funds it needs: a sell reserves the USD amount,
    /// a buy reserves amount × limit in the quote currency.
    /// If the order is already marketable it fills immediately at the current rate, and the fill is returned.
    /// </summary>
    /// <param name="request">The order.</param>
    /// <returns>The order, plus the fill if it filled immediately.</returns>
    /// <response code="201">The order was accepted.</response>
    /// <response code="400">A field is missing or invalid.</response>
    /// <response code="422">There aren't enough available funds to reserve for the order.</response>
    [HttpPost]
    [Consumes("application/json")]
    [ProducesResponseType<PlaceOrderResult>(StatusCodes.Status201Created)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status422UnprocessableEntity)]
    public async Task<ActionResult<PlaceOrderResult>> Place([FromBody] PlaceOrderRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);
        var result = _engine.PlaceOrder(request.ToDomain());
        await _broadcaster.PublishAsync();
        return CreatedAtAction(nameof(Get), new { id = result.Order.Id }, result);
    }

    /// <summary>Cancels an open order and releases its reservation.</summary>
    /// <param name="id">The order id.</param>
    /// <response code="204">The order was cancelled.</response>
    /// <response code="404">No order has that id.</response>
    /// <response code="409">The order is already filled or cancelled.</response>
    /// <returns>No content.</returns>
    [HttpDelete("{id:guid}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<IActionResult> Cancel(Guid id)
    {
        _engine.CancelOrder(id);
        await _broadcaster.PublishAsync();
        return NoContent();
    }
}
