using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.AspNetCore.Mvc;

namespace FxSandbox.Api.Controllers;

/// <summary>Simulated spot rates.</summary>
[ApiController]
[Route("api/rates")]
[Produces("application/json")]
public sealed class RatesController : ControllerBase
{
    private readonly SandboxEngine _engine;

    /// <summary>Creates the controller.</summary>
    /// <param name="engine">The trading engine.</param>
    public RatesController(SandboxEngine engine) => _engine = engine;

    /// <summary>Gets the latest rate for each pair, in quote units per 1 USD.</summary>
    /// <param name="history">Include each pair's recent rate history.</param>
    /// <returns>One rate per pair.</returns>
    [HttpGet]
    [ProducesResponseType<IReadOnlyList<RateView>>(StatusCodes.Status200OK)]
    public IReadOnlyList<RateView> Get([FromQuery] bool history = false) => _engine.GetRates(history);
}
