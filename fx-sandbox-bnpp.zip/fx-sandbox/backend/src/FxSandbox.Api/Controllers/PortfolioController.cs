using FxSandbox.Api.Contracts;
using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.AspNetCore.Mvc;

namespace FxSandbox.Api.Controllers;

/// <summary>Positions and account totals.</summary>
[ApiController]
[Route("api")]
[Produces("application/json")]
public sealed class PortfolioController : ControllerBase
{
    private readonly SandboxEngine _engine;

    /// <summary>Creates the controller.</summary>
    /// <param name="engine">The trading engine.</param>
    public PortfolioController(SandboxEngine engine) => _engine = engine;

    /// <summary>
    /// Gets one position per pair: the quote currency held, its USD cost basis, and P&amp;L marked to the latest rate.
    /// Unrealised P&amp;L = amount ÷ current rate − cost basis.
    /// </summary>
    /// <returns>The positions.</returns>
    [HttpGet("positions")]
    [ProducesResponseType<IReadOnlyList<PositionView>>(StatusCodes.Status200OK)]
    public IReadOnlyList<PositionView> GetPositions() => _engine.GetPositions();

    /// <summary>Gets account totals in USD and wallet balances per currency.</summary>
    /// <returns>The account.</returns>
    [HttpGet("account")]
    [ProducesResponseType<AccountResponse>(StatusCodes.Status200OK)]
    public AccountResponse GetAccount() => AccountResponse.From(_engine.GetSnapshot());
}
