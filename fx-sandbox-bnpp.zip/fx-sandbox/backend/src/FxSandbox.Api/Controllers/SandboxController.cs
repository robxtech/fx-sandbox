using FxSandbox.Api.Infrastructure;
using FxSandbox.Core;
using FxSandbox.Core.Snapshots;
using Microsoft.AspNetCore.Mvc;

namespace FxSandbox.Api.Controllers;

/// <summary>Whole-sandbox operations: the full snapshot and reset.</summary>
[ApiController]
[Route("api")]
[Produces("application/json")]
public sealed class SandboxController : ControllerBase
{
    private readonly SandboxEngine _engine;
    private readonly SnapshotBroadcaster _broadcaster;

    /// <summary>Creates the controller.</summary>
    /// <param name="engine">The trading engine.</param>
    /// <param name="broadcaster">Pushes state changes to connected clients.</param>
    public SandboxController(SandboxEngine engine, SnapshotBroadcaster broadcaster)
    {
        _engine = engine;
        _broadcaster = broadcaster;
    }

    /// <summary>Gets a consistent snapshot of rates, orders, fills, positions, balances and account totals.</summary>
    /// <param name="history">Include each pair's recent rate history (up to 180 points).</param>
    /// <returns>The snapshot.</returns>
    [HttpGet("snapshot")]
    [ProducesResponseType<SandboxSnapshot>(StatusCodes.Status200OK)]
    public SandboxSnapshot GetSnapshot([FromQuery] bool history = false) => _engine.GetSnapshot(history);

    /// <summary>
    /// Resets the account to its starting capital and clears every order, fill and position.
    /// The simulated market keeps running from its current rates.
    /// </summary>
    /// <returns>The snapshot after the reset, with rate history.</returns>
    [HttpPost("reset")]
    [ProducesResponseType<SandboxSnapshot>(StatusCodes.Status200OK)]
    public async Task<SandboxSnapshot> Reset()
    {
        _engine.Reset();
        await _broadcaster.PublishAsync();
        return _engine.GetSnapshot(includeHistory: true);
    }
}
