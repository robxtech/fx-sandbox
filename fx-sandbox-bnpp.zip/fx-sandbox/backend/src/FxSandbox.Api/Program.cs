using System.Reflection;
using System.Text.Json;
using System.Text.Json.Serialization;
using FxSandbox.Api.Hubs;
using FxSandbox.Api.Infrastructure;
using FxSandbox.Core;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Configuration, validated at start-up so a bad setting fails fast.
builder.Services.AddOptions<SandboxSettings>()
    .BindConfiguration(SandboxSettings.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddOptions<TickerOptions>()
    .BindConfiguration(TickerOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddOptions<LiveRatesOptions>()
    .BindConfiguration(LiveRatesOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();

// Domain. The engine is a singleton that serialises all access behind one lock.
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<IRandomSource, SystemRandomSource>();
builder.Services.AddSingleton(sp => new SandboxEngine(
    sp.GetRequiredService<IOptions<SandboxSettings>>().Value,
    sp.GetRequiredService<IRandomSource>(),
    sp.GetRequiredService<TimeProvider>()));
builder.Services.AddSingleton<SnapshotBroadcaster>();

// Hosted services start in registration order: seed the rates, then start ticking.
builder.Services.AddHttpClient<ILiveRateProvider, FrankfurterRateProvider>((sp, client) =>
    client.Timeout = TimeSpan.FromSeconds(sp.GetRequiredService<IOptions<LiveRatesOptions>>().Value.TimeoutSeconds));
builder.Services.AddHostedService<RateSeedingService>();
builder.Services.AddHostedService<TickerService>();

// HTTP API and real-time push, both with string enums.
builder.Services
    .AddControllers(options =>
    {
        options.Filters.Add<SandboxExceptionFilter>();
        options.ModelMetadataDetailsProviders.Add(new SystemTextJsonValidationMetadataProvider());
    })
    .AddJsonOptions(options => ConfigureJson(options.JsonSerializerOptions));
builder.Services.AddProblemDetails();
builder.Services.AddSignalR().AddJsonProtocol(options => ConfigureJson(options.PayloadSerializerOptions));
builder.Services.AddHealthChecks().AddCheck<TickerHealthCheck>("ticker");

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "FX sandbox API",
        Version = "v1",
        Description = "Place simulated limit orders on USD/EUR, USD/GBP and USD/CHF. " +
            "Rates are quote units per 1 USD. Live updates are pushed over SignalR at " + SandboxHub.Path + ".",
    });
    options.SupportNonNullableReferenceTypes();
    foreach (var assembly in new[] { Assembly.GetExecutingAssembly(), typeof(SandboxEngine).Assembly })
    {
        var xml = Path.Combine(AppContext.BaseDirectory, $"{assembly.GetName().Name}.xml");
        if (File.Exists(xml))
        {
            options.IncludeXmlComments(xml, includeControllerXmlComments: true);
        }
    }
});

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

app.UseSwagger();
app.UseSwaggerUI(options => options.DocumentTitle = "FX sandbox API");

// The React build is served from wwwroot, so a single `dotnet run` serves everything.
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapControllers();
app.MapHub<SandboxHub>(SandboxHub.Path);
app.MapHealthChecks("/health", new HealthCheckOptions { ResponseWriter = HealthResponseWriter.WriteAsync });

// Unknown API paths get a ProblemDetails 404; every other path falls back to the SPA.
app.MapFallback("/api/{**path}", () => Results.Problem(
    statusCode: StatusCodes.Status404NotFound,
    title: "Not found",
    detail: "No API endpoint matches this path."));
app.MapFallbackToFile("index.html");

app.Run();

static void ConfigureJson(JsonSerializerOptions options)
{
    options.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    options.Converters.Add(new JsonStringEnumConverter());
}

/// <summary>The application entry point. Declared partial so integration tests can reference it.</summary>
public partial class Program;
