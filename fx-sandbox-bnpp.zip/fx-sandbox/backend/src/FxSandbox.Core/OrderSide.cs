namespace FxSandbox.Core;

/// <summary>
/// The side of an order, from the point of view of the base currency (USD), following market convention.
/// </summary>
public enum OrderSide
{
    /// <summary>Buy USD back, paying in the quote currency. Fills when the rate falls to the limit or lower.</summary>
    Buy,

    /// <summary>Sell USD and receive the quote currency. Fills when the rate rises to the limit or higher.</summary>
    Sell,
}
