namespace FxSandbox.Core;

/// <summary>The simulated rate for one pair, with a bounded history for charts.</summary>
internal sealed class MarketRate
{
    private readonly Queue<decimal> _history = new();
    private readonly int _historyLength;

    public MarketRate(CurrencyPair pair, decimal seedRate, int historyLength)
    {
        Pair = pair;
        _historyLength = historyLength;
        Reseed(seedRate);
    }

    public CurrencyPair Pair { get; }

    public decimal Rate { get; private set; }

    public decimal PreviousRate { get; private set; }

    public decimal SeedRate { get; private set; }

    public IReadOnlyCollection<decimal> History => _history;

    public void Reseed(decimal rate)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(rate);
        var rounded = Money.RoundRate(rate);
        Rate = PreviousRate = SeedRate = rounded;
        _history.Clear();
        _history.Enqueue(rounded);
    }

    public void MoveTo(decimal rate)
    {
        PreviousRate = Rate;
        Rate = rate;
        _history.Enqueue(rate);
        while (_history.Count > _historyLength)
        {
            _history.Dequeue();
        }
    }
}
