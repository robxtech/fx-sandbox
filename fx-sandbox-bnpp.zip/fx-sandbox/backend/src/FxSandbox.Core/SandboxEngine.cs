using FxSandbox.Core.Snapshots;

namespace FxSandbox.Core;

/// <summary>
/// The trading engine: simulated rates, the order book, matching and the wallet.
/// One instance per process. Every public member takes the same lock, so a tick and a trader action
/// never interleave and every snapshot is internally consistent.
/// </summary>
public sealed class SandboxEngine
{
    private readonly object _gate = new();
    private readonly SandboxSettings _settings;
    private readonly IRandomSource _random;
    private readonly TimeProvider _time;
    private readonly Dictionary<CurrencyPair, MarketRate> _markets;
    private readonly Dictionary<Guid, Order> _orders = [];
    private readonly List<Order> _openOrders = [];
    private readonly LinkedList<Order> _closedOrders = new();
    private readonly LinkedList<FillView> _fills = new();

    private Wallet _wallet;
    private SeedView _seed;
    private long _tick;
    private long _orderSequence;
    private long _fillSequence;

    /// <summary>Creates an engine seeded from the configured fallback rates.</summary>
    /// <param name="settings">Engine settings.</param>
    /// <param name="random">The source of random samples for the walk.</param>
    /// <param name="time">The clock used for timestamps.</param>
    public SandboxEngine(SandboxSettings settings, IRandomSource random, TimeProvider time)
    {
        ArgumentNullException.ThrowIfNull(settings);
        ArgumentNullException.ThrowIfNull(random);
        ArgumentNullException.ThrowIfNull(time);

        _settings = settings;
        _random = random;
        _time = time;
        _wallet = new Wallet(settings.StartingCapital);

        var seed = RateSeed.FromSettings(settings);
        _markets = CurrencyPair.All.ToDictionary(p => p, p => new MarketRate(p, seed.Rates[p], settings.HistoryLength));
        _seed = new SeedView(seed.Source, seed.Description, seed.AsOf, time.GetUtcNow());
    }

    /// <summary>When the last tick ran, or null before the first tick.</summary>
    public DateTimeOffset? LastTickAt { get; private set; }

    /// <summary>
    /// Restarts every pair's walk from new rates, for example live rates fetched at start-up.
    /// Clears rate history; the account and orders are left alone.
    /// </summary>
    /// <param name="seed">The new starting rates. Must cover every simulated pair.</param>
    public void Seed(RateSeed seed)
    {
        ArgumentNullException.ThrowIfNull(seed);
        var missing = CurrencyPair.All.Where(p => !seed.Rates.TryGetValue(p, out var r) || r <= 0).ToList();
        if (missing.Count > 0)
        {
            throw new ArgumentException($"The seed is missing a positive rate for {string.Join(", ", missing)}.", nameof(seed));
        }

        lock (_gate)
        {
            foreach (var (pair, market) in _markets)
            {
                market.Reseed(seed.Rates[pair]);
            }

            _seed = new SeedView(seed.Source, seed.Description, seed.AsOf, _time.GetUtcNow());
        }
    }

    /// <summary>Advances every pair one step of the random walk, then fills any orders the new rates reach.</summary>
    /// <returns>The tick number and the fills it produced, in execution order.</returns>
    public TickResult Tick()
    {
        lock (_gate)
        {
            _tick++;
            foreach (var market in _markets.Values)
            {
                market.MoveTo(RandomWalk.Next(market.Rate, _random.NextDouble(), _settings.MaxStep));
            }

            var fills = MatchOpenOrders();
            LastTickAt = _time.GetUtcNow();
            return new TickResult(_tick, fills);
        }
    }

    /// <summary>
    /// Validates and places a limit order, reserving the funds it needs.
    /// An order that is already marketable fills straight away at the current spot rate.
    /// </summary>
    /// <param name="request">The order to place.</param>
    /// <returns>The order and, if it filled immediately, the fill.</returns>
    /// <exception cref="OrderValidationException">A field is invalid.</exception>
    /// <exception cref="InsufficientFundsException">The wallet can't cover the reservation.</exception>
    public PlaceOrderResult PlaceOrder(OrderRequest request)
    {
        ArgumentNullException.ThrowIfNull(request);

        lock (_gate)
        {
            var pair = Validate(request);
            var (currency, amount) = request.Side == OrderSide.Sell
                ? (Currencies.Usd, request.Quantity)
                : (pair.Quote, Money.RoundAmount(request.Quantity * request.LimitPrice));

            _wallet.Reserve(currency, amount);

            var order = new Order(
                Guid.NewGuid(),
                ++_orderSequence,
                pair,
                request.Side,
                request.Quantity,
                request.LimitPrice,
                currency,
                amount,
                _time.GetUtcNow());
            _orders.Add(order.Id, order);
            _openOrders.Add(order);

            var spot = _markets[pair].Rate;
            var fill = order.IsMarketableAt(spot) ? Execute(order, spot) : null;
            return new PlaceOrderResult(ToView(order), fill);
        }
    }

    /// <summary>Cancels an open order and releases its reservation.</summary>
    /// <param name="orderId">The order to cancel.</param>
    /// <returns>The cancelled order.</returns>
    /// <exception cref="OrderNotFoundException">No order has that id.</exception>
    /// <exception cref="OrderNotCancellableException">The order is already filled or cancelled.</exception>
    public OrderView CancelOrder(Guid orderId)
    {
        lock (_gate)
        {
            if (!_orders.TryGetValue(orderId, out var order))
            {
                throw new OrderNotFoundException(orderId);
            }

            if (order.Status != OrderStatus.Open)
            {
                throw new OrderNotCancellableException(orderId, order.Status);
            }

            _wallet.Release(order.ReservedCurrency, order.ReservedAmount);
            order.MarkCancelled(_time.GetUtcNow());
            Close(order);
            return ToView(order);
        }
    }

    /// <summary>
    /// Restores the starting capital and clears every order, fill and position.
    /// The simulated market keeps running from its current rates.
    /// </summary>
    public void Reset()
    {
        lock (_gate)
        {
            _wallet = new Wallet(_settings.StartingCapital);
            _orders.Clear();
            _openOrders.Clear();
            _closedOrders.Clear();
            _fills.Clear();
        }
    }

    /// <summary>Takes a consistent snapshot of the whole sandbox.</summary>
    /// <param name="includeHistory">Whether to include each pair's recent rate history.</param>
    /// <returns>The snapshot.</returns>
    public SandboxSnapshot GetSnapshot(bool includeHistory = false)
    {
        lock (_gate)
        {
            return new SandboxSnapshot(
                _tick,
                _time.GetUtcNow(),
                _seed,
                RateViews(includeHistory),
                OrderViews(status: null),
                [.. _fills],
                PositionViews(),
                BalanceViews(),
                AccountSummary());
        }
    }

    /// <summary>The latest rate for each pair.</summary>
    /// <param name="includeHistory">Whether to include recent rate history.</param>
    /// <returns>One rate per pair.</returns>
    public IReadOnlyList<RateView> GetRates(bool includeHistory = false)
    {
        lock (_gate)
        {
            return RateViews(includeHistory);
        }
    }

    /// <summary>Orders in the book: open ones oldest first, then closed ones newest first.</summary>
    /// <param name="status">Only return orders with this status, or null for all.</param>
    /// <returns>The matching orders.</returns>
    public IReadOnlyList<OrderView> GetOrders(OrderStatus? status = null)
    {
        lock (_gate)
        {
            return OrderViews(status);
        }
    }

    /// <summary>Looks up one order.</summary>
    /// <param name="orderId">The order id.</param>
    /// <returns>The order, or null if it doesn't exist.</returns>
    public OrderView? GetOrder(Guid orderId)
    {
        lock (_gate)
        {
            return _orders.TryGetValue(orderId, out var order) ? ToView(order) : null;
        }
    }

    /// <summary>One position per pair, marked to the latest rates.</summary>
    /// <returns>The positions.</returns>
    public IReadOnlyList<PositionView> GetPositions()
    {
        lock (_gate)
        {
            return PositionViews();
        }
    }

    /// <summary>Wallet balances per currency.</summary>
    /// <returns>The balances.</returns>
    public IReadOnlyList<BalanceView> GetBalances()
    {
        lock (_gate)
        {
            return BalanceViews();
        }
    }

    /// <summary>Account-level totals in USD.</summary>
    /// <returns>The account summary.</returns>
    public AccountView GetAccount()
    {
        lock (_gate)
        {
            return AccountSummary();
        }
    }

    /// <summary>Unrounded account totals, used to check the accounting identity in tests.</summary>
    internal (decimal AccountValue, decimal Unrealised, decimal Realised) ValueAccountExactly()
    {
        lock (_gate)
        {
            return ValueAccount();
        }
    }

    private CurrencyPair Validate(OrderRequest request)
    {
        var errors = new Dictionary<string, string[]>();

        if (!CurrencyPair.TryParse(request.Pair, out var pair))
        {
            var known = string.Join(", ", CurrencyPair.All.Select(p => p.Symbol));
            errors["pair"] = [$"Choose one of {known}."];
        }

        if (!Enum.IsDefined(request.Side))
        {
            errors["side"] = ["Side must be Buy or Sell."];
        }

        if (request.Quantity <= 0)
        {
            errors["quantity"] = ["Enter a USD amount greater than zero."];
        }
        else if (!Money.HasAtMostDecimals(request.Quantity, Money.AmountDecimals))
        {
            errors["quantity"] = ["USD amounts can have at most 2 decimal places."];
        }

        if (request.LimitPrice <= 0)
        {
            errors["limitPrice"] = ["Enter a limit rate greater than zero."];
        }
        else if (!Money.HasAtMostDecimals(request.LimitPrice, Money.RateDecimals))
        {
            errors["limitPrice"] = ["Limit rates can have at most 5 decimal places."];
        }
        else if (pair is not null)
        {
            var spot = _markets[pair].Rate;
            var deviation = Math.Abs((request.LimitPrice / spot) - 1m);
            if (deviation > _settings.MaxLimitDeviation)
            {
                errors["limitPrice"] =
                [
                    $"The limit rate must be within {_settings.MaxLimitDeviation * 100m:0.##}% of the current {pair.Symbol} rate ({spot:F5}).",
                ];
            }
        }

        if (errors.Count > 0)
        {
            throw new OrderValidationException(errors);
        }

        return pair!;
    }

    private List<FillView> MatchOpenOrders()
    {
        // Price-time priority: the most aggressive limit first, then the oldest order at the same level.
        // Every triggered order executes at the same spot rate, so priority only decides the fill sequence.
        var triggered = _openOrders
            .Where(o => o.IsMarketableAt(_markets[o.Pair].Rate))
            .OrderBy(o => o.Pair.Symbol, StringComparer.Ordinal)
            .ThenBy(o => o.Side == OrderSide.Sell ? o.LimitPrice : -o.LimitPrice)
            .ThenBy(o => o.Sequence)
            .ToList();

        return triggered.Select(o => Execute(o, _markets[o.Pair].Rate)).ToList();
    }

    private FillView Execute(Order order, decimal rate)
    {
        _wallet.Release(order.ReservedCurrency, order.ReservedAmount);

        decimal quoteAmount;
        decimal? realised = null;
        if (order.Side == OrderSide.Sell)
        {
            quoteAmount = _wallet.SellUsd(order.Pair, order.Quantity, rate);
        }
        else
        {
            (quoteAmount, var pnl) = _wallet.BuyUsd(order.Pair, order.Quantity, rate);
            realised = pnl;
        }

        var now = _time.GetUtcNow();
        order.MarkFilled(rate, quoteAmount, now);
        Close(order);

        var fill = new FillView(
            ++_fillSequence,
            order.Id,
            order.Pair.Symbol,
            order.Side,
            order.Quantity,
            order.LimitPrice,
            rate,
            quoteAmount,
            realised,
            now);

        _fills.AddFirst(fill);
        while (_fills.Count > _settings.FillRetention)
        {
            _fills.RemoveLast();
        }

        return fill;
    }

    private void Close(Order order)
    {
        _openOrders.Remove(order);
        _closedOrders.AddFirst(order);
        while (_closedOrders.Count > _settings.ClosedOrderRetention)
        {
            _orders.Remove(_closedOrders.Last!.Value.Id);
            _closedOrders.RemoveLast();
        }
    }

    private (decimal AccountValue, decimal Unrealised, decimal Realised) ValueAccount()
    {
        var marketValue = 0m;
        var unrealised = 0m;
        var realised = 0m;
        foreach (var position in _wallet.Positions)
        {
            var rate = _markets[position.Pair].Rate;
            marketValue += position.MarketValueUsd(rate);
            unrealised += position.UnrealisedPnlUsd(rate);
            realised += position.RealisedPnlUsd;
        }

        return (_wallet.UsdCash + marketValue, unrealised, realised);
    }

    private AccountView AccountSummary()
    {
        var (value, unrealised, realised) = ValueAccount();
        return new AccountView(
            _settings.StartingCapital,
            _wallet.UsdCash,
            Money.RoundAmount(value),
            Money.RoundAmount(unrealised),
            Money.RoundAmount(realised));
    }

    private List<RateView> RateViews(bool includeHistory) =>
        _markets.Values.Select(m => new RateView(
            m.Pair.Symbol,
            m.Pair.Base,
            m.Pair.Quote,
            m.Rate,
            m.PreviousRate,
            m.SeedRate,
            Math.Round(((m.Rate / m.SeedRate) - 1m) * 100m, 4),
            includeHistory ? [.. m.History] : null)).ToList();

    private List<OrderView> OrderViews(OrderStatus? status) =>
        _openOrders.Concat(_closedOrders)
            .Where(o => status is null || o.Status == status)
            .Select(ToView)
            .ToList();

    private List<PositionView> PositionViews() =>
        _wallet.Positions.Select(p =>
        {
            var rate = _markets[p.Pair].Rate;
            return new PositionView(
                p.Pair.Symbol,
                p.Pair.Quote,
                p.Amount,
                p.CostBasisUsd,
                p.CostBasisUsd > 0 ? Money.RoundRate(p.Amount / p.CostBasisUsd) : null,
                rate,
                Money.RoundAmount(p.MarketValueUsd(rate)),
                Money.RoundAmount(p.UnrealisedPnlUsd(rate)),
                p.RealisedPnlUsd);
        }).ToList();

    private List<BalanceView> BalanceViews() =>
        Currencies.All.Select(c => new BalanceView(c, _wallet.Balance(c), _wallet.Reserved(c), _wallet.Available(c))).ToList();

    private static OrderView ToView(Order o) => new(
        o.Id,
        o.Pair.Symbol,
        o.Side,
        o.Quantity,
        o.LimitPrice,
        o.Status,
        o.ReservedCurrency,
        o.ReservedAmount,
        o.CreatedAt,
        o.ClosedAt,
        o.FillPrice,
        o.QuoteAmount);
}
