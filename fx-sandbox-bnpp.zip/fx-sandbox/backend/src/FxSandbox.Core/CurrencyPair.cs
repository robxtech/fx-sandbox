using System.Diagnostics.CodeAnalysis;

namespace FxSandbox.Core;

/// <summary>
/// A currency pair quoted as BASE/QUOTE. The rate is the number of quote units for one base unit,
/// so USD/EUR 0.87890 means 1 USD buys 0.87890 EUR.
/// </summary>
/// <param name="Base">The base currency code, always USD in this sandbox.</param>
/// <param name="Quote">The quote currency code, for example EUR.</param>
public sealed record CurrencyPair(string Base, string Quote)
{
    /// <summary>USD/EUR.</summary>
    public static readonly CurrencyPair UsdEur = new(Currencies.Usd, Currencies.Eur);

    /// <summary>USD/GBP.</summary>
    public static readonly CurrencyPair UsdGbp = new(Currencies.Usd, Currencies.Gbp);

    /// <summary>USD/CHF.</summary>
    public static readonly CurrencyPair UsdChf = new(Currencies.Usd, Currencies.Chf);

    /// <summary>The pairs the sandbox simulates, in display order.</summary>
    public static IReadOnlyList<CurrencyPair> All { get; } = [UsdEur, UsdGbp, UsdChf];

    /// <summary>The display symbol, for example "USD/EUR".</summary>
    public string Symbol => $"{Base}/{Quote}";

    /// <summary>
    /// Parses a pair symbol. Accepts "USD/EUR", "USDEUR" and "usd-eur", case-insensitively,
    /// and only returns pairs the sandbox simulates.
    /// </summary>
    /// <param name="value">The text to parse.</param>
    /// <param name="pair">The matching pair, when parsing succeeds.</param>
    /// <returns><c>true</c> when <paramref name="value"/> names a simulated pair.</returns>
    public static bool TryParse(string? value, [NotNullWhen(true)] out CurrencyPair? pair)
    {
        pair = null;
        if (string.IsNullOrWhiteSpace(value))
        {
            return false;
        }

        var compact = value.Trim().Replace("/", "", StringComparison.Ordinal).Replace("-", "", StringComparison.Ordinal);
        pair = All.FirstOrDefault(p => string.Equals(p.Base + p.Quote, compact, StringComparison.OrdinalIgnoreCase));
        return pair is not null;
    }

    /// <summary>Finds the simulated pair whose quote currency is <paramref name="quoteCurrency"/>.</summary>
    /// <param name="quoteCurrency">A quote currency code such as EUR.</param>
    /// <returns>The pair, or <c>null</c> if no simulated pair uses that quote currency.</returns>
    public static CurrencyPair? ForQuote(string quoteCurrency) =>
        All.FirstOrDefault(p => string.Equals(p.Quote, quoteCurrency, StringComparison.OrdinalIgnoreCase));

    /// <inheritdoc />
    public override string ToString() => Symbol;
}
