namespace FxSandbox.Core;

/// <summary>
/// The rate simulation from the brief: <c>newRate = oldRate × (1 + Δ)</c> with Δ drawn uniformly from
/// [-maxStep, +maxStep] (maxStep defaults to 0.001, so ±0.1% per tick).
/// </summary>
public static class RandomWalk
{
    /// <summary>The largest relative move per tick given in the brief.</summary>
    public const decimal DefaultMaxStep = 0.001m;

    /// <summary>Maps a uniform sample in [0, 1] onto Δ in [-maxStep, +maxStep].</summary>
    /// <param name="sample">A value between 0 and 1 inclusive.</param>
    /// <param name="maxStep">The largest relative move allowed.</param>
    /// <returns>The relative change Δ.</returns>
    public static decimal Delta(double sample, decimal maxStep = DefaultMaxStep)
    {
        if (double.IsNaN(sample) || sample < 0d || sample > 1d)
        {
            throw new ArgumentOutOfRangeException(nameof(sample), sample, "The sample must be between 0 and 1.");
        }

        ArgumentOutOfRangeException.ThrowIfNegative(maxStep);
        return (((decimal)sample * 2m) - 1m) * maxStep;
    }

    /// <summary>
    /// Takes one step of the walk and rounds the result to 5 dp.
    /// Rounding is towards the previous rate, so a rounded step is never larger than the unrounded one
    /// and the ±maxStep bound always holds exactly.
    /// </summary>
    /// <param name="rate">The current rate. Must be positive.</param>
    /// <param name="sample">A value between 0 and 1 inclusive.</param>
    /// <param name="maxStep">The largest relative move allowed.</param>
    /// <returns>The next rate.</returns>
    public static decimal Next(decimal rate, double sample, decimal maxStep = DefaultMaxStep)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(rate);

        var raw = rate * (1m + Delta(sample, maxStep));
        var towardsPrevious = raw >= rate ? MidpointRounding.ToNegativeInfinity : MidpointRounding.ToPositiveInfinity;
        return Math.Round(raw, Money.RateDecimals, towardsPrevious);
    }
}
