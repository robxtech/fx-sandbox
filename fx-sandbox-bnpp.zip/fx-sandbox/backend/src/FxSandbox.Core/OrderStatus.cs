namespace FxSandbox.Core;

/// <summary>The lifecycle state of an order.</summary>
public enum OrderStatus
{
    /// <summary>Resting in the book, with funds reserved.</summary>
    Open,

    /// <summary>Executed in full at the spot rate on the tick that triggered it.</summary>
    Filled,

    /// <summary>Cancelled by the trader; its reservation was released.</summary>
    Cancelled,
}
