namespace FxSandbox.Core;

/// <summary>Where the starting rates of the random walk came from.</summary>
public enum RateSeedSource
{
    /// <summary>Live ECB reference rates, fetched at start-up.</summary>
    Live,

    /// <summary>Rates from configuration, used when live rates are disabled or unavailable.</summary>
    Configured,
}
