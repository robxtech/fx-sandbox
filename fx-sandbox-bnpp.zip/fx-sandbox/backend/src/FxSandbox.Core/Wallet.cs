namespace FxSandbox.Core;

/// <summary>
/// The multi-currency wallet: USD cash plus one position per pair, with amounts reserved by open orders.
/// No leverage or shorting: every order must be fully covered by available funds.
/// </summary>
internal sealed class Wallet
{
    private readonly Dictionary<string, decimal> _reserved = new(StringComparer.Ordinal);
    private readonly Dictionary<CurrencyPair, Position> _positions;

    public Wallet(decimal startingCapital)
    {
        UsdCash = startingCapital;
        _positions = CurrencyPair.All.ToDictionary(p => p, p => new Position(p));
    }

    public decimal UsdCash { get; private set; }

    public IReadOnlyCollection<Position> Positions => _positions.Values;

    public Position PositionFor(CurrencyPair pair) => _positions[pair];

    public decimal Balance(string currency)
    {
        if (currency == Currencies.Usd)
        {
            return UsdCash;
        }

        var pair = CurrencyPair.ForQuote(currency)
            ?? throw new ArgumentException($"Unknown currency {currency}.", nameof(currency));
        return _positions[pair].Amount;
    }

    public decimal Reserved(string currency) => _reserved.GetValueOrDefault(currency);

    public decimal Available(string currency) => Balance(currency) - Reserved(currency);

    public void Reserve(string currency, decimal amount)
    {
        var available = Available(currency);
        if (amount > available)
        {
            throw new InsufficientFundsException(currency, amount, available);
        }

        _reserved[currency] = Reserved(currency) + amount;
    }

    public void Release(string currency, decimal amount)
    {
        var remaining = Reserved(currency) - amount;
        if (remaining < 0)
        {
            throw new InvalidOperationException($"Released more {currency} than was reserved.");
        }

        _reserved[currency] = remaining;
    }

    /// <summary>Sells <paramref name="usd"/> at <paramref name="rate"/>. Returns the quote amount received.</summary>
    public decimal SellUsd(CurrencyPair pair, decimal usd, decimal rate)
    {
        var received = Money.RoundAmount(usd * rate);
        UsdCash -= usd;
        _positions[pair].Add(received, usd);
        return received;
    }

    /// <summary>Buys <paramref name="usd"/> at <paramref name="rate"/>. Returns the quote amount paid and realised P&amp;L.</summary>
    public (decimal Paid, decimal RealisedPnl) BuyUsd(CurrencyPair pair, decimal usd, decimal rate)
    {
        var paid = Money.RoundAmount(usd * rate);
        var realised = _positions[pair].Reduce(paid, usd);
        UsdCash += usd;
        return (paid, realised);
    }
}
