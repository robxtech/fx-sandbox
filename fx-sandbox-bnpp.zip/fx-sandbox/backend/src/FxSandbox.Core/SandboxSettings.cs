using System.ComponentModel.DataAnnotations;

namespace FxSandbox.Core;

/// <summary>Settings for the trading engine. Bound from the "Sandbox" configuration section.</summary>
public sealed class SandboxSettings
{
    /// <summary>The configuration section name.</summary>
    public const string SectionName = "Sandbox";

    /// <summary>USD cash the account starts with, and returns to on reset.</summary>
    [Range(typeof(decimal), "0.01", "1000000000")]
    public decimal StartingCapital { get; set; } = 10_000m;

    /// <summary>How many rates to keep per pair for the charts.</summary>
    [Range(2, 10_000)]
    public int HistoryLength { get; set; } = 180;

    /// <summary>The largest relative move per tick (Δ bound).</summary>
    [Range(typeof(decimal), "0", "0.1")]
    public decimal MaxStep { get; set; } = RandomWalk.DefaultMaxStep;

    /// <summary>
    /// A fat-finger check: limit prices further than this fraction from spot are rejected.
    /// 0.2 means the limit must be within 20% of the current rate.
    /// </summary>
    [Range(typeof(decimal), "0.0001", "10")]
    public decimal MaxLimitDeviation { get; set; } = 0.2m;

    /// <summary>How many filled and cancelled orders to keep for the order book.</summary>
    [Range(1, 10_000)]
    public int ClosedOrderRetention { get; set; } = 200;

    /// <summary>How many recent fills to keep.</summary>
    [Range(1, 10_000)]
    public int FillRetention { get; set; } = 100;

    /// <summary>
    /// Starting rates keyed by quote currency (EUR, GBP, CHF), used when live rates are off or unavailable.
    /// </summary>
    [Required]
    public Dictionary<string, decimal> FallbackRates { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        [Currencies.Eur] = 0.8789m,
        [Currencies.Gbp] = 0.7462m,
        [Currencies.Chf] = 0.8012m,
    };
}
