namespace FxSandbox.Core.Snapshots;

/// <summary>A full, immutable picture of the sandbox at one moment. Pushed to clients every tick.</summary>
/// <param name="Tick">The number of ticks since start-up. Increases by one per simulated second.</param>
/// <param name="Timestamp">When the snapshot was taken (UTC).</param>
/// <param name="Seed">Where the starting rates came from.</param>
/// <param name="Rates">The latest rate for each pair.</param>
/// <param name="Orders">Open orders, then recently filled and cancelled ones, newest first.</param>
/// <param name="Fills">Recent fills, newest first.</param>
/// <param name="Positions">One position per pair.</param>
/// <param name="Balances">Wallet balances per currency.</param>
/// <param name="Account">Account-level totals in USD.</param>
public sealed record SandboxSnapshot(
    long Tick,
    DateTimeOffset Timestamp,
    SeedView Seed,
    IReadOnlyList<RateView> Rates,
    IReadOnlyList<OrderView> Orders,
    IReadOnlyList<FillView> Fills,
    IReadOnlyList<PositionView> Positions,
    IReadOnlyList<BalanceView> Balances,
    AccountView Account);

/// <summary>Where the starting rates came from.</summary>
/// <param name="Source">Live or configured.</param>
/// <param name="Description">A plain-English description of the source.</param>
/// <param name="AsOf">The date the reference rates apply to, when known.</param>
/// <param name="SeededAt">When the walk was seeded (UTC).</param>
public sealed record SeedView(RateSeedSource Source, string Description, DateOnly? AsOf, DateTimeOffset SeededAt);

/// <summary>The latest simulated rate for a pair.</summary>
/// <param name="Pair">The pair symbol, for example USD/EUR.</param>
/// <param name="Base">The base currency (USD).</param>
/// <param name="Quote">The quote currency.</param>
/// <param name="Rate">Quote units per 1 USD, to 5 dp.</param>
/// <param name="PreviousRate">The rate on the previous tick.</param>
/// <param name="SeedRate">The rate the walk started from.</param>
/// <param name="ChangePercent">The change since the seed, in percent.</param>
/// <param name="History">The most recent rates, oldest first, ending with <paramref name="Rate"/>. Null unless requested.</param>
public sealed record RateView(
    string Pair,
    string Base,
    string Quote,
    decimal Rate,
    decimal PreviousRate,
    decimal SeedRate,
    decimal ChangePercent,
    IReadOnlyList<decimal>? History);

/// <summary>A limit order as seen by clients.</summary>
/// <param name="Id">The order id.</param>
/// <param name="Pair">The pair symbol.</param>
/// <param name="Side">Sell USD (fills on a rise) or buy USD (fills on a fall).</param>
/// <param name="Quantity">The USD amount.</param>
/// <param name="LimitPrice">The limit rate.</param>
/// <param name="Status">Open, filled or cancelled.</param>
/// <param name="ReservedCurrency">The currency reserved while the order is open.</param>
/// <param name="ReservedAmount">The amount reserved while the order is open.</param>
/// <param name="CreatedAt">When the order was placed (UTC).</param>
/// <param name="ClosedAt">When it was filled or cancelled (UTC).</param>
/// <param name="FillPrice">The rate it filled at.</param>
/// <param name="QuoteAmount">The quote-currency amount received (sell) or paid (buy) on the fill.</param>
public sealed record OrderView(
    Guid Id,
    string Pair,
    OrderSide Side,
    decimal Quantity,
    decimal LimitPrice,
    OrderStatus Status,
    string ReservedCurrency,
    decimal ReservedAmount,
    DateTimeOffset CreatedAt,
    DateTimeOffset? ClosedAt,
    decimal? FillPrice,
    decimal? QuoteAmount);

/// <summary>An execution.</summary>
/// <param name="Sequence">Monotonic fill number.</param>
/// <param name="OrderId">The order that filled.</param>
/// <param name="Pair">The pair symbol.</param>
/// <param name="Side">The order side.</param>
/// <param name="Quantity">The USD amount.</param>
/// <param name="LimitPrice">The order's limit rate.</param>
/// <param name="Price">The spot rate it executed at, at the limit or better.</param>
/// <param name="QuoteAmount">The quote-currency amount received (sell) or paid (buy).</param>
/// <param name="RealisedPnl">USD P&amp;L booked by a buy, or null for a sell.</param>
/// <param name="Timestamp">When it executed (UTC).</param>
public sealed record FillView(
    long Sequence,
    Guid OrderId,
    string Pair,
    OrderSide Side,
    decimal Quantity,
    decimal LimitPrice,
    decimal Price,
    decimal QuoteAmount,
    decimal? RealisedPnl,
    DateTimeOffset Timestamp);

/// <summary>A holding of a quote currency, marked to the latest rate.</summary>
/// <param name="Pair">The pair symbol.</param>
/// <param name="Currency">The quote currency held.</param>
/// <param name="Amount">The quote-currency amount held.</param>
/// <param name="CostBasisUsd">The USD paid for the amount held.</param>
/// <param name="AverageRate">The average rate paid (amount ÷ cost), or null when flat.</param>
/// <param name="CurrentRate">The latest rate.</param>
/// <param name="MarketValueUsd">amount ÷ current rate.</param>
/// <param name="UnrealisedPnl">market value − cost basis, in USD.</param>
/// <param name="RealisedPnl">USD P&amp;L booked by buying USD back.</param>
public sealed record PositionView(
    string Pair,
    string Currency,
    decimal Amount,
    decimal CostBasisUsd,
    decimal? AverageRate,
    decimal CurrentRate,
    decimal MarketValueUsd,
    decimal UnrealisedPnl,
    decimal RealisedPnl);

/// <summary>A wallet balance.</summary>
/// <param name="Currency">The currency code.</param>
/// <param name="Balance">Total held.</param>
/// <param name="Reserved">Held back for open orders.</param>
/// <param name="Available">Free to use for new orders.</param>
public sealed record BalanceView(string Currency, decimal Balance, decimal Reserved, decimal Available);

/// <summary>Account-level totals, all in USD.</summary>
/// <param name="StartingCapital">The capital the account started with.</param>
/// <param name="UsdCash">USD held, including any reserved for orders.</param>
/// <param name="AccountValue">USD cash plus every position marked to USD.</param>
/// <param name="UnrealisedPnl">The sum of unrealised P&amp;L across positions.</param>
/// <param name="RealisedPnl">The sum of realised P&amp;L across positions.</param>
public sealed record AccountView(
    decimal StartingCapital,
    decimal UsdCash,
    decimal AccountValue,
    decimal UnrealisedPnl,
    decimal RealisedPnl);

/// <summary>The outcome of placing an order.</summary>
/// <param name="Order">The order, which is already filled if it was marketable.</param>
/// <param name="Fill">The immediate fill, if the order was marketable when placed.</param>
public sealed record PlaceOrderResult(OrderView Order, FillView? Fill);

/// <summary>The outcome of one tick.</summary>
/// <param name="Tick">The tick number.</param>
/// <param name="Fills">Orders filled on this tick, in execution order.</param>
public sealed record TickResult(long Tick, IReadOnlyList<FillView> Fills);
