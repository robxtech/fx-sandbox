namespace FxSandbox.Core;

/// <summary>A limit order. Mutable, and only ever touched inside the engine's lock.</summary>
internal sealed class Order
{
    public Order(
        Guid id,
        long sequence,
        CurrencyPair pair,
        OrderSide side,
        decimal quantity,
        decimal limitPrice,
        string reservedCurrency,
        decimal reservedAmount,
        DateTimeOffset createdAt)
    {
        Id = id;
        Sequence = sequence;
        Pair = pair;
        Side = side;
        Quantity = quantity;
        LimitPrice = limitPrice;
        ReservedCurrency = reservedCurrency;
        ReservedAmount = reservedAmount;
        CreatedAt = createdAt;
    }

    public Guid Id { get; }

    /// <summary>Monotonic arrival number, used for time priority.</summary>
    public long Sequence { get; }

    public CurrencyPair Pair { get; }

    public OrderSide Side { get; }

    /// <summary>The USD amount to sell or buy.</summary>
    public decimal Quantity { get; }

    public decimal LimitPrice { get; }

    public string ReservedCurrency { get; }

    public decimal ReservedAmount { get; }

    public DateTimeOffset CreatedAt { get; }

    public OrderStatus Status { get; private set; } = OrderStatus.Open;

    public DateTimeOffset? ClosedAt { get; private set; }

    public decimal? FillPrice { get; private set; }

    public decimal? QuoteAmount { get; private set; }

    /// <summary>Whether the order would fill at <paramref name="rate"/>.</summary>
    public bool IsMarketableAt(decimal rate) => Side switch
    {
        OrderSide.Sell => rate >= LimitPrice,
        OrderSide.Buy => rate <= LimitPrice,
        _ => throw new InvalidOperationException($"Unknown side {Side}."),
    };

    public void MarkFilled(decimal price, decimal quoteAmount, DateTimeOffset at)
    {
        EnsureOpen();
        Status = OrderStatus.Filled;
        FillPrice = price;
        QuoteAmount = quoteAmount;
        ClosedAt = at;
    }

    public void MarkCancelled(DateTimeOffset at)
    {
        EnsureOpen();
        Status = OrderStatus.Cancelled;
        ClosedAt = at;
    }

    private void EnsureOpen()
    {
        if (Status != OrderStatus.Open)
        {
            throw new InvalidOperationException($"Order {Id} is already {Status}.");
        }
    }
}
