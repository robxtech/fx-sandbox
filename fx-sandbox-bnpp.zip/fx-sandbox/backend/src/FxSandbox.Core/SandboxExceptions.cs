using System.Globalization;

namespace FxSandbox.Core;

/// <summary>Base type for expected, trader-facing rejections raised by the engine.</summary>
public abstract class SandboxException : Exception
{
    /// <summary>Creates the exception with a trader-facing message.</summary>
    /// <param name="message">A plain-English explanation.</param>
    protected SandboxException(string message)
        : base(message)
    {
    }
}

/// <summary>An order request had invalid fields. Maps to HTTP 400.</summary>
public sealed class OrderValidationException : SandboxException
{
    /// <summary>Creates the exception from per-field errors.</summary>
    /// <param name="errors">Messages keyed by the request field they relate to.</param>
    public OrderValidationException(IReadOnlyDictionary<string, string[]> errors)
        : base(string.Join(" ", errors.SelectMany(e => e.Value)))
    {
        Errors = errors;
    }

    /// <summary>Messages keyed by request field name (pair, side, quantity, limitPrice).</summary>
    public IReadOnlyDictionary<string, string[]> Errors { get; }
}

/// <summary>The wallet does not hold enough of a currency to reserve for an order. Maps to HTTP 422.</summary>
public sealed class InsufficientFundsException : SandboxException
{
    /// <summary>Creates the exception.</summary>
    /// <param name="currency">The currency that is short.</param>
    /// <param name="required">The amount the order needs reserved.</param>
    /// <param name="available">The amount currently available.</param>
    public InsufficientFundsException(string currency, decimal required, decimal available)
        : base(string.Format(
            CultureInfo.InvariantCulture,
            "Not enough {0}: this order needs {1:N2} and {2:N2} is available.",
            currency,
            required,
            available))
    {
        Currency = currency;
        Required = required;
        Available = available;
    }

    /// <summary>The currency that is short.</summary>
    public string Currency { get; }

    /// <summary>The amount the order needs reserved.</summary>
    public decimal Required { get; }

    /// <summary>The amount currently available.</summary>
    public decimal Available { get; }
}

/// <summary>No order has the requested id. Maps to HTTP 404.</summary>
public sealed class OrderNotFoundException : SandboxException
{
    /// <summary>Creates the exception.</summary>
    /// <param name="orderId">The id that was not found.</param>
    public OrderNotFoundException(Guid orderId)
        : base($"Order {orderId} was not found.")
    {
        OrderId = orderId;
    }

    /// <summary>The id that was not found.</summary>
    public Guid OrderId { get; }
}

/// <summary>The order exists but is no longer open. Maps to HTTP 409.</summary>
public sealed class OrderNotCancellableException : SandboxException
{
    /// <summary>Creates the exception.</summary>
    /// <param name="orderId">The order that could not be cancelled.</param>
    /// <param name="status">Its current status.</param>
    public OrderNotCancellableException(Guid orderId, OrderStatus status)
        : base($"Order {orderId} is already {status.ToString().ToLowerInvariant()}, so it can't be cancelled.")
    {
        OrderId = orderId;
        Status = status;
    }

    /// <summary>The order that could not be cancelled.</summary>
    public Guid OrderId { get; }

    /// <summary>Its current status.</summary>
    public OrderStatus Status { get; }
}
