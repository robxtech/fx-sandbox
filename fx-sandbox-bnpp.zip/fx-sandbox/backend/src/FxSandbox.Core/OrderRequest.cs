namespace FxSandbox.Core;

/// <summary>A request to place a limit order. Validated by the engine.</summary>
/// <param name="Pair">The pair symbol, for example USD/EUR.</param>
/// <param name="Side">Sell USD or buy USD.</param>
/// <param name="Quantity">The USD amount, up to 2 dp.</param>
/// <param name="LimitPrice">The limit rate, up to 5 dp.</param>
public sealed record OrderRequest(string Pair, OrderSide Side, decimal Quantity, decimal LimitPrice);
