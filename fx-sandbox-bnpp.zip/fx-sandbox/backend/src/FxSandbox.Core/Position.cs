namespace FxSandbox.Core;

/// <summary>
/// The quote-currency amount held for one pair, with its USD cost basis and the P&amp;L booked so far.
/// </summary>
internal sealed class Position
{
    public Position(CurrencyPair pair) => Pair = pair;

    public CurrencyPair Pair { get; }

    /// <summary>Quote-currency amount held, for example EUR for USD/EUR.</summary>
    public decimal Amount { get; private set; }

    /// <summary>USD paid for <see cref="Amount"/>.</summary>
    public decimal CostBasisUsd { get; private set; }

    /// <summary>USD P&amp;L booked by buying USD back.</summary>
    public decimal RealisedPnlUsd { get; private set; }

    /// <summary>Records a sell of USD: <paramref name="usdSold"/> bought <paramref name="quoteReceived"/>.</summary>
    public void Add(decimal quoteReceived, decimal usdSold)
    {
        Amount += quoteReceived;
        CostBasisUsd += usdSold;
    }

    /// <summary>
    /// Records a buy of USD: <paramref name="quotePaid"/> bought back <paramref name="usdBought"/>.
    /// The cost basis is reduced pro rata and the difference is booked as realised P&amp;L.
    /// </summary>
    /// <returns>The realised P&amp;L in USD.</returns>
    public decimal Reduce(decimal quotePaid, decimal usdBought)
    {
        if (quotePaid > Amount)
        {
            throw new InvalidOperationException(
                $"Cannot pay {quotePaid} {Pair.Quote} from a position of {Amount}. Reservations should prevent this.");
        }

        var costReleased = quotePaid == Amount
            ? CostBasisUsd
            : Money.RoundAmount(CostBasisUsd * quotePaid / Amount);

        Amount -= quotePaid;
        CostBasisUsd -= costReleased;

        var realised = usdBought - costReleased;
        RealisedPnlUsd += realised;
        return realised;
    }

    /// <summary>The USD value of the holding at <paramref name="rate"/>, unrounded.</summary>
    public decimal MarketValueUsd(decimal rate) => Amount / rate;

    /// <summary>Unrealised P&amp;L at <paramref name="rate"/>, unrounded.</summary>
    public decimal UnrealisedPnlUsd(decimal rate) => MarketValueUsd(rate) - CostBasisUsd;
}
