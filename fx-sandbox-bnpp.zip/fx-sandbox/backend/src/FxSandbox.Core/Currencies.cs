namespace FxSandbox.Core;

/// <summary>ISO 4217 codes for the currencies the sandbox holds.</summary>
public static class Currencies
{
    /// <summary>US dollar, the account's base and reporting currency.</summary>
    public const string Usd = "USD";

    /// <summary>Euro.</summary>
    public const string Eur = "EUR";

    /// <summary>Pound sterling.</summary>
    public const string Gbp = "GBP";

    /// <summary>Swiss franc.</summary>
    public const string Chf = "CHF";

    /// <summary>Every wallet currency, USD first.</summary>
    public static IReadOnlyList<string> All { get; } = [Usd, Eur, Gbp, Chf];
}
