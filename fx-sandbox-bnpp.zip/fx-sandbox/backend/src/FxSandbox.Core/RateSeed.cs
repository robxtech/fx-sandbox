namespace FxSandbox.Core;

/// <summary>The starting rates for the random walk and where they came from.</summary>
/// <param name="Source">Whether the rates are live or configured.</param>
/// <param name="Rates">One positive rate per simulated pair.</param>
/// <param name="Description">A plain-English description of the source, shown in the UI.</param>
/// <param name="AsOf">The date the reference rates apply to, when known.</param>
public sealed record RateSeed(
    RateSeedSource Source,
    IReadOnlyDictionary<CurrencyPair, decimal> Rates,
    string Description,
    DateOnly? AsOf = null)
{
    /// <summary>Builds a seed from the configured fallback rates.</summary>
    /// <param name="settings">The engine settings holding the fallback rates.</param>
    /// <param name="reason">Why the configured rates are in use, appended to the description.</param>
    /// <returns>A configured seed covering every simulated pair.</returns>
    public static RateSeed FromSettings(SandboxSettings settings, string? reason = null)
    {
        ArgumentNullException.ThrowIfNull(settings);

        var rates = new Dictionary<CurrencyPair, decimal>();
        foreach (var pair in CurrencyPair.All)
        {
            if (!settings.FallbackRates.TryGetValue(pair.Quote, out var rate) || rate <= 0)
            {
                throw new InvalidOperationException(
                    $"Configure a positive fallback rate for {pair.Quote} under {SandboxSettings.SectionName}:FallbackRates.");
            }

            rates[pair] = rate;
        }

        var description = reason is null ? "Configured rates" : $"Configured rates ({reason})";
        return new RateSeed(RateSeedSource.Configured, rates, description);
    }
}
