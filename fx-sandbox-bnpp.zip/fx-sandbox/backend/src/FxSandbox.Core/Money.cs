namespace FxSandbox.Core;

/// <summary>Rounding and precision rules shared by the whole domain.</summary>
public static class Money
{
    /// <summary>Decimal places for currency amounts and order quantities.</summary>
    public const int AmountDecimals = 2;

    /// <summary>Decimal places for exchange rates.</summary>
    public const int RateDecimals = 5;

    /// <summary>The smallest amount the sandbox can represent.</summary>
    public const decimal MinimumAmount = 0.01m;

    /// <summary>Rounds a currency amount to 2 dp, half away from zero.</summary>
    /// <param name="value">The unrounded amount.</param>
    /// <returns>The amount rounded to <see cref="AmountDecimals"/> places.</returns>
    public static decimal RoundAmount(decimal value) =>
        Math.Round(value, AmountDecimals, MidpointRounding.AwayFromZero);

    /// <summary>Rounds a rate to 5 dp, half away from zero.</summary>
    /// <param name="value">The unrounded rate.</param>
    /// <returns>The rate rounded to <see cref="RateDecimals"/> places.</returns>
    public static decimal RoundRate(decimal value) =>
        Math.Round(value, RateDecimals, MidpointRounding.AwayFromZero);

    /// <summary>Returns <c>true</c> when <paramref name="value"/> has no more than <paramref name="decimals"/> decimal places.</summary>
    /// <param name="value">The value to check.</param>
    /// <param name="decimals">The maximum number of decimal places.</param>
    /// <returns>Whether rounding to <paramref name="decimals"/> places leaves the value unchanged.</returns>
    public static bool HasAtMostDecimals(decimal value, int decimals) =>
        Math.Round(value, decimals) == value;
}
