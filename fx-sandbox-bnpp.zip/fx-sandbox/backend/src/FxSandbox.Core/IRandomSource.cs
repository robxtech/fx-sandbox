namespace FxSandbox.Core;

/// <summary>Supplies the random samples that drive the rate simulation. Tests swap in a scripted source.</summary>
public interface IRandomSource
{
    /// <summary>Returns a sample in the range [0, 1].</summary>
    /// <returns>A value between 0 and 1 inclusive.</returns>
    double NextDouble();
}

/// <summary>An <see cref="IRandomSource"/> backed by <see cref="Random"/>.</summary>
public sealed class SystemRandomSource : IRandomSource
{
    private readonly Random _random;

    /// <summary>Creates a source using the shared, thread-safe <see cref="Random"/> instance.</summary>
    public SystemRandomSource()
        : this(Random.Shared)
    {
    }

    /// <summary>Creates a source around a specific <see cref="Random"/>, for example a seeded one.</summary>
    /// <param name="random">The generator to draw from.</param>
    public SystemRandomSource(Random random)
    {
        ArgumentNullException.ThrowIfNull(random);
        _random = random;
    }

    /// <inheritdoc />
    public double NextDouble() => _random.NextDouble();
}
